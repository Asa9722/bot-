export function formatDateTime(date: Date | string | null | undefined): string {
  if (!date) return "–";
  const d = new Date(date);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

export function formatPrice(v: number | null | undefined, decimals = 2): string {
  if (v == null) return "–";
  return v.toFixed(decimals);
}

export function formatPercent(v: number | null | undefined): string {
  if (v == null) return "–";
  const sign = v >= 0 ? "+" : "";
  return `${sign}${v.toFixed(2)}%`;
}

export function formatUsd(v: number | null | undefined): string {
  if (v == null) return "–";
  const sign = v >= 0 ? "+" : "";
  return `${sign}$${Math.abs(v).toFixed(2)}`;
}

export function profitColor(v: number | null | undefined): string {
  if (v == null) return "text-gray-400";
  return v >= 0 ? "text-emerald-400" : "text-red-400";
}

export function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

export function getSessionLabel(hour: number): string {
  if (hour >= 1 && hour < 8) return "ASIAN";
  if (hour >= 8 && hour < 16) return "LONDON";
  if (hour >= 13 && hour < 22) return "NEW_YORK";
  return "OFF";
}

export const WEEKDAYS = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];
