import { NextResponse } from "next/server";
import { db } from "@/db";
import { marketSnapshots } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    // Last 120 snapshots for charts
    const snapshots = await db
      .select()
      .from(marketSnapshots)
      .orderBy(desc(marketSnapshots.recordedAt))
      .limit(120);

    return NextResponse.json({
      success: true,
      snapshots: snapshots.reverse(),
    });
  } catch (err) {
    return NextResponse.json({ success: false, error: String(err) }, { status: 500 });
  }
}
