import { NextResponse } from "next/server";
import { db } from "@/db";
import { botSettings, trades, equityCurve, marketSnapshots, systemLogs } from "@/db/schema";
import { eq, desc, and } from "drizzle-orm";

export async function GET() {
  try {
    const settings = await db.select().from(botSettings);
    const settingsMap = Object.fromEntries(settings.map((s) => [s.key, s.value]));

    const openTrades = await db
      .select()
      .from(trades)
      .where(eq(trades.status, "OPEN"))
      .orderBy(desc(trades.openedAt));

    const latestEquity = await db
      .select()
      .from(equityCurve)
      .orderBy(desc(equityCurve.recordedAt))
      .limit(1);

    const latestSnapshot = await db
      .select()
      .from(marketSnapshots)
      .orderBy(desc(marketSnapshots.recordedAt))
      .limit(1);

    const recentLogs = await db
      .select()
      .from(systemLogs)
      .orderBy(desc(systemLogs.createdAt))
      .limit(15);

    // Simulate live gold price fluctuation
    const basePrice = latestSnapshot[0]?.price ?? 2345.5;
    const livePrice = basePrice + (Math.random() - 0.5) * 0.8;

    const equity = parseFloat(settingsMap.account_equity ?? "10000");
    const balance = parseFloat(settingsMap.account_balance ?? "10000");

    return NextResponse.json({
      success: true,
      bot: {
        active: settingsMap.bot_active === "true",
        mode: settingsMap.bot_mode ?? "PAPER",
        account: settingsMap.mt5_account,
        server: settingsMap.mt5_server,
        currency: settingsMap.account_currency ?? "USD",
        timezone: settingsMap.timezone ?? "Europe/Vienna",
      },
      market: {
        price: Math.round(livePrice * 100) / 100,
        bid: Math.round((livePrice - 0.15) * 100) / 100,
        ask: Math.round((livePrice + 0.15) * 100) / 100,
        spread: 0.30,
        atr: latestSnapshot[0]?.atr ?? 12.5,
        rsi: latestSnapshot[0]?.rsi ?? 55,
        adx: latestSnapshot[0]?.adx ?? 28,
        macd: latestSnapshot[0]?.macd ?? 0.5,
        ema20: latestSnapshot[0]?.ema20 ?? 2340,
        ema50: latestSnapshot[0]?.ema50 ?? 2330,
        ema200: latestSnapshot[0]?.ema200 ?? 2310,
        signalScore: latestSnapshot[0]?.signalScore ?? 72,
        marketPhase: latestSnapshot[0]?.marketPhase ?? "TREND",
        trendDirection: latestSnapshot[0]?.trendDirection ?? "LONG",
        volume: latestSnapshot[0]?.volume ?? 1200,
        relativeVolume: latestSnapshot[0]?.relativeVolume ?? 1.2,
        bbUpper: latestSnapshot[0]?.bbUpper ?? 2360,
        bbLower: latestSnapshot[0]?.bbLower ?? 2330,
      },
      account: {
        equity: Math.round((equity + (Math.random() - 0.3) * 5) * 100) / 100,
        balance,
        freeMargin: Math.round(balance * 0.82 * 100) / 100,
        marginLevel: Math.round(randomBetween(300, 800) * 100) / 100,
        drawdown: Math.round(((balance - equity) / balance) * 10000) / 100,
        openPositions: openTrades.length,
      },
      openTrades,
      recentLogs,
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ success: false, error: String(err) }, { status: 500 });
  }
}

function randomBetween(a: number, b: number) {
  return Math.random() * (b - a) + a;
}
