import { NextResponse, NextRequest } from "next/server";
import { db } from "@/db";
import { botSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const settings = await db.select().from(botSettings).orderBy(botSettings.key);
    const map = Object.fromEntries(settings.map((s) => [s.key, s.value]));
    return NextResponse.json({ success: true, settings: map });
  } catch (err) {
    return NextResponse.json({ success: false, error: String(err) }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json() as Record<string, string>;
    for (const [key, value] of Object.entries(body)) {
      await db
        .insert(botSettings)
        .values({ key, value })
        .onConflictDoUpdate({ target: botSettings.key, set: { value, updatedAt: new Date() } });
    }
    return NextResponse.json({ success: true, updated: Object.keys(body).length });
  } catch (err) {
    return NextResponse.json({ success: false, error: String(err) }, { status: 500 });
  }
}
