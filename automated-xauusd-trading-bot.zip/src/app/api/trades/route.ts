import { NextResponse, NextRequest } from "next/server";
import { db } from "@/db";
import { trades } from "@/db/schema";
import { eq, desc, and, not } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status");
    const limit = parseInt(searchParams.get("limit") ?? "50");

    let query = db.select().from(trades).orderBy(desc(trades.openedAt)).limit(limit);

    let rows;
    if (status) {
      rows = await db
        .select()
        .from(trades)
        .where(eq(trades.status, status))
        .orderBy(desc(trades.openedAt))
        .limit(limit);
    } else {
      rows = await query;
    }

    return NextResponse.json({ success: true, trades: rows });
  } catch (err) {
    return NextResponse.json({ success: false, error: String(err) }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json() as {
      action: string;
      tradeId?: number;
      stopLoss?: number;
      takeProfit?: number;
      partialPercent?: number;
    };

    if (body.action === "close" && body.tradeId) {
      await db
        .update(trades)
        .set({
          status: "CLOSED",
          exitReason: "MANUAL",
          closedAt: new Date(),
          exitPrice: 2345 + Math.random() * 10 - 5,
        })
        .where(eq(trades.id, body.tradeId));
      return NextResponse.json({ success: true, message: "Trade manuell geschlossen" });
    }

    if (body.action === "partial" && body.tradeId) {
      await db
        .update(trades)
        .set({
          status: "PARTIAL",
          partialClosed: true,
          partialPercent: body.partialPercent ?? 50,
          exitReason: "PARTIAL_MANUAL",
        })
        .where(eq(trades.id, body.tradeId));
      return NextResponse.json({ success: true, message: "Teilverkauf durchgeführt" });
    }

    if (body.action === "modify" && body.tradeId) {
      const updates: Record<string, number> = {};
      if (body.stopLoss) updates.stopLoss = body.stopLoss;
      if (body.takeProfit) updates.takeProfit = body.takeProfit;
      await db.update(trades).set(updates).where(eq(trades.id, body.tradeId));
      return NextResponse.json({ success: true, message: "Trade modifiziert" });
    }

    if (body.action === "close_all") {
      await db
        .update(trades)
        .set({
          status: "CLOSED",
          exitReason: "MANUAL_ALL",
          closedAt: new Date(),
        })
        .where(eq(trades.status, "OPEN"));
      return NextResponse.json({ success: true, message: "Alle Trades geschlossen" });
    }

    return NextResponse.json({ success: false, error: "Unbekannte Aktion" }, { status: 400 });
  } catch (err) {
    return NextResponse.json({ success: false, error: String(err) }, { status: 500 });
  }
}
