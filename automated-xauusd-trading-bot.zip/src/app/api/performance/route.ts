import { NextResponse } from "next/server";
import { db } from "@/db";
import { trades, performanceLogs, equityCurve, adaptiveData } from "@/db/schema";
import { eq, desc, and, not, sql } from "drizzle-orm";

export async function GET() {
  try {
    // All closed trades
    const closedTrades = await db
      .select()
      .from(trades)
      .where(eq(trades.status, "CLOSED"))
      .orderBy(desc(trades.closedAt));

    const total = closedTrades.length;
    const wins = closedTrades.filter((t) => (t.profitUsd ?? 0) > 0).length;
    const losses = total - wins;
    const totalProfit = closedTrades.reduce((s, t) => s + (t.profitUsd ?? 0), 0);
    const winRate = total > 0 ? (wins / total) * 100 : 0;
    const avgProfit = wins > 0
      ? closedTrades.filter((t) => (t.profitUsd ?? 0) > 0).reduce((s, t) => s + (t.profitUsd ?? 0), 0) / wins
      : 0;
    const avgLoss = losses > 0
      ? closedTrades.filter((t) => (t.profitUsd ?? 0) <= 0).reduce((s, t) => s + (t.profitUsd ?? 0), 0) / losses
      : 0;
    const profitFactor = avgLoss !== 0 ? Math.abs(avgProfit / avgLoss) : 0;
    const avgRR = avgLoss !== 0 ? Math.abs(avgProfit / avgLoss) : 0;

    // Long vs Short
    const longs = closedTrades.filter((t) => t.direction === "LONG");
    const shorts = closedTrades.filter((t) => t.direction === "SHORT");
    const longWins = longs.filter((t) => (t.profitUsd ?? 0) > 0).length;
    const shortWins = shorts.filter((t) => (t.profitUsd ?? 0) > 0).length;

    // By market phase
    const byPhase: Record<string, { total: number; wins: number; profit: number }> = {};
    for (const t of closedTrades) {
      const p = t.marketPhase ?? "UNKNOWN";
      if (!byPhase[p]) byPhase[p] = { total: 0, wins: 0, profit: 0 };
      byPhase[p].total++;
      if ((t.profitUsd ?? 0) > 0) byPhase[p].wins++;
      byPhase[p].profit += t.profitUsd ?? 0;
    }

    // By exit reason
    const byExit: Record<string, { count: number; profit: number }> = {};
    for (const t of closedTrades) {
      const e = t.exitReason ?? "UNKNOWN";
      if (!byExit[e]) byExit[e] = { count: 0, profit: 0 };
      byExit[e].count++;
      byExit[e].profit += t.profitUsd ?? 0;
    }

    // Equity curve
    const equityData = await db
      .select()
      .from(equityCurve)
      .orderBy(desc(equityCurve.recordedAt))
      .limit(60);

    // Performance logs by weekday
    const perfLogs = await db
      .select()
      .from(performanceLogs)
      .orderBy(desc(performanceLogs.createdAt))
      .limit(500);

    const byWeekday: Record<number, { profit: number; count: number }> = {};
    const byHour: Record<number, { profit: number; count: number }> = {};
    const bySession: Record<string, { profit: number; count: number }> = {};

    for (const p of perfLogs) {
      const wd = p.weekday ?? 0;
      if (!byWeekday[wd]) byWeekday[wd] = { profit: 0, count: 0 };
      byWeekday[wd].profit += p.profitUsd ?? 0;
      byWeekday[wd].count += p.totalTrades ?? 0;

      const h = p.hour ?? 0;
      if (!byHour[h]) byHour[h] = { profit: 0, count: 0 };
      byHour[h].profit += p.profitUsd ?? 0;
      byHour[h].count += p.totalTrades ?? 0;

      const sess = p.session ?? "UNKNOWN";
      if (!bySession[sess]) bySession[sess] = { profit: 0, count: 0 };
      bySession[sess].profit += p.profitUsd ?? 0;
      bySession[sess].count += p.totalTrades ?? 0;
    }

    // Adaptive data
    const adaptive = await db.select().from(adaptiveData).orderBy(desc(adaptiveData.updatedAt));

    // Max drawdown from equity
    let peak = 0;
    let maxDD = 0;
    for (const e of [...equityData].reverse()) {
      if (e.equity > peak) peak = e.equity;
      const dd = ((peak - e.equity) / peak) * 100;
      if (dd > maxDD) maxDD = dd;
    }

    return NextResponse.json({
      success: true,
      summary: {
        total,
        wins,
        losses,
        winRate: Math.round(winRate * 10) / 10,
        totalProfit: Math.round(totalProfit * 100) / 100,
        avgProfit: Math.round(avgProfit * 100) / 100,
        avgLoss: Math.round(avgLoss * 100) / 100,
        profitFactor: Math.round(profitFactor * 100) / 100,
        avgRR: Math.round(avgRR * 100) / 100,
        maxDrawdown: Math.round(maxDD * 100) / 100,
        longTrades: longs.length,
        shortTrades: shorts.length,
        longWinRate: longs.length > 0 ? Math.round((longWins / longs.length) * 1000) / 10 : 0,
        shortWinRate: shorts.length > 0 ? Math.round((shortWins / shorts.length) * 1000) / 10 : 0,
        bestTrade: Math.max(...closedTrades.map((t) => t.profitUsd ?? 0)),
        worstTrade: Math.min(...closedTrades.map((t) => t.profitUsd ?? 0)),
      },
      byPhase,
      byExit,
      byWeekday,
      byHour,
      bySession,
      equityData: equityData.reverse(),
      adaptive,
      recentTrades: closedTrades.slice(0, 20),
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ success: false, error: String(err) }, { status: 500 });
  }
}
