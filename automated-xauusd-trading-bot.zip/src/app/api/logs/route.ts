import { NextResponse, NextRequest } from "next/server";
import { db } from "@/db";
import { systemLogs, telegramLogs } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const type = searchParams.get("type") ?? "system";
    const limit = parseInt(searchParams.get("limit") ?? "100");

    if (type === "telegram") {
      const logs = await db
        .select()
        .from(telegramLogs)
        .orderBy(desc(telegramLogs.createdAt))
        .limit(limit);
      return NextResponse.json({ success: true, logs });
    }

    const logs = await db
      .select()
      .from(systemLogs)
      .orderBy(desc(systemLogs.createdAt))
      .limit(limit);

    return NextResponse.json({ success: true, logs });
  } catch (err) {
    return NextResponse.json({ success: false, error: String(err) }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json() as {
      level: "INFO" | "WARN" | "ERROR";
      category: string;
      message: string;
      data?: Record<string, unknown>;
    };

    await db.insert(systemLogs).values({
      level: body.level,
      category: body.category,
      message: body.message,
      data: body.data ?? null,
    });

    return NextResponse.json({ success: true });
  } catch (err) {
    return NextResponse.json({ success: false, error: String(err) }, { status: 500 });
  }
}
