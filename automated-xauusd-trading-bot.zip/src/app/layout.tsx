import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "🥇 GOLD Bot – XAUUSD Professional Trading System",
  description: "Vollautomatischer Gold (XAUUSD) Trading Bot – Professionelles Dashboard",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="de">
      <body>{children}</body>
    </html>
  );
}
