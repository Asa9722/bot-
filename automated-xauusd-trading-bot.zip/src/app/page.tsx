"use client";
import { useState, useEffect, useCallback, useRef } from "react";
import LiveHeader from "@/components/LiveHeader";
import OpenTrades from "@/components/OpenTrades";
import MarketPanel from "@/components/MarketPanel";
import PerformancePanel from "@/components/PerformancePanel";
import SettingsPanel from "@/components/SettingsPanel";
import LogsPanel from "@/components/LogsPanel";

type Tab = "live" | "market" | "performance" | "history" | "settings" | "logs";

interface StatusData {
  bot: {
    active: boolean;
    mode: string;
    account: string;
    server: string;
    currency: string;
    timezone: string;
  };
  market: {
    price: number;
    bid: number;
    ask: number;
    spread: number;
    atr: number;
    rsi: number;
    adx: number;
    macd: number;
    ema20: number;
    ema50: number;
    ema200: number;
    signalScore: number;
    marketPhase: string;
    trendDirection: string;
    volume: number;
    relativeVolume: number;
    bbUpper: number;
    bbLower: number;
  };
  account: {
    equity: number;
    balance: number;
    freeMargin: number;
    marginLevel: number;
    drawdown: number;
    openPositions: number;
  };
  openTrades: Trade[];
  recentLogs: LogEntry[];
}

interface Trade {
  id: number;
  ticketId: string | null;
  direction: string;
  status: string;
  entryPrice: number;
  currentPrice: number | null;
  stopLoss: number | null;
  takeProfit: number | null;
  lotSize: number;
  signalScore: number | null;
  signalReason: string | null;
  marketPhase: string | null;
  trendStrength: number | null;
  atrAtEntry: number | null;
  rsiAtEntry: number | null;
  adxAtEntry: number | null;
  trailingActive: boolean | null;
  breakEvenSet: boolean | null;
  partialClosed: boolean | null;
  openedAt: string | null;
}

interface LogEntry {
  id: number;
  level: string;
  category: string | null;
  message: string;
  createdAt: string | null;
}

interface PerformanceData {
  summary: {
    total: number;
    wins: number;
    losses: number;
    winRate: number;
    totalProfit: number;
    avgProfit: number;
    avgLoss: number;
    profitFactor: number;
    avgRR: number;
    maxDrawdown: number;
    longTrades: number;
    shortTrades: number;
    longWinRate: number;
    shortWinRate: number;
    bestTrade: number;
    worstTrade: number;
  };
  equityData: {
    equity: number;
    balance: number;
    drawdown: number;
    openPositions: number;
    recordedAt: string | null;
  }[];
  byPhase: Record<string, { total: number; wins: number; profit: number }>;
  byExit: Record<string, { count: number; profit: number }>;
  byWeekday: Record<number, { profit: number; count: number }>;
  byHour: Record<number, { profit: number; count: number }>;
  bySession: Record<string, { profit: number; count: number }>;
  recentTrades: {
    id: number;
    direction: string;
    profitUsd: number | null;
    profitPips: number | null;
    exitReason: string | null;
    openedAt: string | null;
    holdingMinutes: number | null;
    marketPhase: string | null;
    signalScore: number | null;
  }[];
  adaptive: {
    paramName: string;
    paramValue: number;
    successRate: number | null;
    sampleCount: number | null;
    avgProfit: number | null;
  }[];
}

interface Snapshot {
  price: number;
  rsi: number | null;
  macd: number | null;
  atr: number | null;
  adx: number | null;
  ema20: number | null;
  ema50: number | null;
  ema100: number | null;
  ema200: number | null;
  bbUpper: number | null;
  bbLower: number | null;
  bbMiddle: number | null;
  stochK: number | null;
  stochD: number | null;
  volume: number | null;
  relativeVolume: number | null;
  signalScore: number | null;
  recordedAt: string | null;
}

export default function Dashboard() {
  const [tab, setTab] = useState<Tab>("live");
  const [status, setStatus] = useState<StatusData | null>(null);
  const [performance, setPerformance] = useState<PerformanceData | null>(null);
  const [snapshots, setSnapshots] = useState<Snapshot[]>([]);
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [historyTrades, setHistoryTrades] = useState<Trade[]>([]);
  const [loading, setLoading] = useState(true);
  const [notification, setNotification] = useState<{ msg: string; type: "success" | "error" | "info" } | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const showNotification = (msg: string, type: "success" | "error" | "info" = "success") => {
    setNotification({ msg, type });
    setTimeout(() => setNotification(null), 3000);
  };

  const fetchStatus = useCallback(async () => {
    try {
      const r = await fetch("/api/bot/status");
      const data = await r.json() as StatusData & { success: boolean };
      if (data.success) setStatus(data);
    } catch (e) {
      console.error("Status fetch error", e);
    }
  }, []);

  const fetchPerformance = useCallback(async () => {
    try {
      const r = await fetch("/api/performance");
      const data = await r.json() as PerformanceData & { success: boolean };
      if (data.success) setPerformance(data);
    } catch (e) {
      console.error("Performance fetch error", e);
    }
  }, []);

  const fetchMarket = useCallback(async () => {
    try {
      const r = await fetch("/api/market");
      const data = await r.json() as { success: boolean; snapshots: Snapshot[] };
      if (data.success) setSnapshots(data.snapshots);
    } catch (e) {
      console.error("Market fetch error", e);
    }
  }, []);

  const fetchSettings = useCallback(async () => {
    try {
      const r = await fetch("/api/bot/settings");
      const data = await r.json() as { success: boolean; settings: Record<string, string> };
      if (data.success) setSettings(data.settings);
    } catch (e) {
      console.error("Settings fetch error", e);
    }
  }, []);

  const fetchLogs = useCallback(async () => {
    try {
      const r = await fetch("/api/logs");
      const data = await r.json() as { success: boolean; logs: LogEntry[] };
      if (data.success) setLogs(data.logs);
    } catch (e) {
      console.error("Logs fetch error", e);
    }
  }, []);

  const fetchHistory = useCallback(async () => {
    try {
      const r = await fetch("/api/trades?status=CLOSED&limit=100");
      const data = await r.json() as { success: boolean; trades: Trade[] };
      if (data.success) setHistoryTrades(data.trades);
    } catch (e) {
      console.error("History fetch error", e);
    }
  }, []);

  // Initial load
  useEffect(() => {
    Promise.all([fetchStatus(), fetchPerformance(), fetchMarket(), fetchSettings(), fetchLogs()])
      .finally(() => setLoading(false));
  }, [fetchStatus, fetchPerformance, fetchMarket, fetchSettings, fetchLogs]);

  // Auto-refresh every 3 seconds for live data
  useEffect(() => {
    intervalRef.current = setInterval(() => {
      fetchStatus();
      if (tab === "market") fetchMarket();
    }, 3000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [tab, fetchStatus, fetchMarket]);

  // Tab-specific fetches
  useEffect(() => {
    if (tab === "performance") fetchPerformance();
    if (tab === "market") fetchMarket();
    if (tab === "settings") fetchSettings();
    if (tab === "logs") fetchLogs();
    if (tab === "history") fetchHistory();
  }, [tab, fetchPerformance, fetchMarket, fetchSettings, fetchLogs, fetchHistory]);

  // Trade actions
  const handleCloseTrade = async (id: number) => {
    const r = await fetch("/api/trades", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "close", tradeId: id }),
    });
    const data = await r.json() as { success: boolean; message?: string };
    if (data.success) {
      showNotification("✅ Trade geschlossen");
      fetchStatus();
    }
  };

  const handlePartialClose = async (id: number, pct: number) => {
    const r = await fetch("/api/trades", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "partial", tradeId: id, partialPercent: pct }),
    });
    const data = await r.json() as { success: boolean };
    if (data.success) {
      showNotification(`✅ ${pct}% Teilverkauf durchgeführt`);
      fetchStatus();
    }
  };

  const handleModifyTrade = async (id: number, sl: number, tp: number) => {
    const r = await fetch("/api/trades", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "modify", tradeId: id, stopLoss: sl, takeProfit: tp }),
    });
    const data = await r.json() as { success: boolean };
    if (data.success) showNotification("✅ Trade modifiziert");
  };

  const handleCloseAll = async () => {
    if (!confirm("Alle offenen Positionen schließen?")) return;
    const r = await fetch("/api/trades", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "close_all" }),
    });
    const data = await r.json() as { success: boolean };
    if (data.success) {
      showNotification("✅ Alle Trades geschlossen", "info");
      fetchStatus();
    }
  };

  const handleToggleBot = async () => {
    const newVal = status?.bot.active ? "false" : "true";
    await fetch("/api/bot/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ bot_active: newVal }),
    });
    showNotification(newVal === "true" ? "✅ Bot aktiviert" : "⏸ Bot pausiert", "info");
    fetchStatus();
  };

  const handlePauseBot = async () => {
    const current = status?.bot.mode;
    const newMode = current === "PAUSE" ? "LIVE" : "PAUSE";
    await fetch("/api/bot/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ bot_mode: newMode }),
    });
    showNotification(newMode === "PAUSE" ? "⏸ Bot pausiert" : "▶ Bot fortgesetzt");
    fetchStatus();
  };

  const handleSaveSettings = async (updates: Record<string, string>) => {
    await fetch("/api/bot/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updates),
    });
    setSettings(updates);
    showNotification("✅ Einstellungen gespeichert");
  };

  const TABS: { key: Tab; label: string; icon: string }[] = [
    { key: "live", label: "Live Trading", icon: "📡" },
    { key: "market", label: "Marktanalyse", icon: "📊" },
    { key: "performance", label: "Performance", icon: "📈" },
    { key: "history", label: "Trade History", icon: "📋" },
    { key: "settings", label: "Einstellungen", icon: "⚙️" },
    { key: "logs", label: "System Log", icon: "📝" },
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#060810" }}>
        <div className="text-center">
          <div className="text-6xl mb-4" style={{ animation: "pulse-gold 2s infinite" }}>🥇</div>
          <div className="text-2xl font-black mb-2" style={{ color: "#f5c518" }}>GOLD BOT</div>
          <div className="text-gray-400">Verbinde mit XAUUSD...</div>
          <div className="mt-4 flex justify-center gap-1">
            {[0, 1, 2].map((i) => (
              <div key={i} className="w-2 h-2 rounded-full" style={{
                background: "#f5c518",
                animation: `pulse-green 1.4s ${i * 0.2}s infinite`
              }}></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const mkt = status?.market;
  const acc = status?.account;

  return (
    <div className="min-h-screen" style={{ background: "#060810" }}>
      {/* Notification Toast */}
      {notification && (
        <div
          className="fixed top-4 right-4 z-[100] px-5 py-3 rounded-xl font-bold text-sm shadow-2xl transition-all"
          style={{
            background: notification.type === "error" ? "#1a0a0a" : "#0a1a0a",
            border: `1px solid ${notification.type === "error" ? "#ef4444" : notification.type === "info" ? "#60a5fa" : "#10b981"}60`,
            color: notification.type === "error" ? "#ef4444" : notification.type === "info" ? "#60a5fa" : "#10b981",
          }}
        >
          {notification.msg}
        </div>
      )}

      {/* Header */}
      {status && (
        <LiveHeader
          price={mkt?.price ?? 2345}
          spread={mkt?.spread ?? 0.3}
          bid={mkt?.bid ?? 2344.85}
          ask={mkt?.ask ?? 2345.15}
          botActive={status.bot.active}
          botMode={status.bot.mode}
          account={status.bot.account}
          equity={acc?.equity ?? 10000}
          balance={acc?.balance ?? 10000}
          drawdown={acc?.drawdown ?? 0}
          openPositions={acc?.openPositions ?? 0}
          signalScore={mkt?.signalScore ?? 70}
          marketPhase={mkt?.marketPhase ?? "TREND"}
          trendDirection={mkt?.trendDirection ?? "NEUTRAL"}
          atr={mkt?.atr ?? 12}
          onToggleBot={handleToggleBot}
          onPause={handlePauseBot}
          onCloseAll={handleCloseAll}
        />
      )}

      {/* Tab Navigation */}
      <div className="sticky top-0 z-40 px-4 py-2 flex gap-2 overflow-x-auto" style={{
        background: "#060810",
        borderBottom: "1px solid #1f2937",
        top: 120 // below header
      }}>
        {TABS.map((t) => (
          <button
            key={t.key}
            className={`tab ${tab === t.key ? "active" : ""}`}
            onClick={() => setTab(t.key)}
          >
            <span className="mr-1.5">{t.icon}</span>
            {t.label}
          </button>
        ))}
        <div className="ml-auto flex items-center gap-2 flex-shrink-0">
          <div className="text-xs text-gray-600">Auto-Refresh: 3s</div>
          <div className="status-dot active"></div>
        </div>
      </div>

      {/* Main Content */}
      <main className="px-4 py-4 max-w-[1600px] mx-auto">

        {/* ───── LIVE TRADING TAB ───── */}
        {tab === "live" && (
          <div className="space-y-4">
            {/* Quick Stats */}
            <div className="grid grid-cols-6 gap-3">
              {[
                { label: "Offene Trades", value: acc?.openPositions ?? 0, suffix: "", color: "gold" },
                { label: "Equity", value: `$${(acc?.equity ?? 0).toFixed(2)}`, suffix: "", color: "green" },
                { label: "Drawdown", value: `${(acc?.drawdown ?? 0).toFixed(2)}%`, suffix: "", color: (acc?.drawdown ?? 0) > 3 ? "red" : "green" },
                { label: "Freie Margin", value: `$${(acc?.freeMargin ?? 0).toFixed(2)}`, suffix: "", color: "blue" },
                { label: "Signal Score", value: `${mkt?.signalScore ?? 0}/100`, suffix: "", color: "purple" },
                { label: "ATR", value: (mkt?.atr ?? 0).toFixed(2), suffix: "", color: "gold" },
              ].map((m) => (
                <div key={m.label} className={`metric-card ${m.color}`}>
                  <div className="text-xs text-gray-500 mb-1">{m.label}</div>
                  <div className={`font-black text-lg ${
                    m.color === "gold" ? "text-yellow-400" :
                    m.color === "green" ? "text-emerald-400" :
                    m.color === "red" ? "text-red-400" :
                    m.color === "blue" ? "text-blue-400" : "text-purple-400"
                  }`}>{m.value}</div>
                </div>
              ))}
            </div>

            {/* Market Summary */}
            <div className="grid grid-cols-4 gap-3">
              <div className="card-gold">
                <div className="text-xs text-gray-500 mb-1">RSI (14)</div>
                <div className={`font-black text-2xl ${
                  (mkt?.rsi ?? 50) > 70 ? "text-red-400" :
                  (mkt?.rsi ?? 50) < 30 ? "text-emerald-400" : "text-yellow-400"
                }`}>{(mkt?.rsi ?? 0).toFixed(1)}</div>
                <div className="text-xs text-gray-500 mt-1">
                  {(mkt?.rsi ?? 50) > 70 ? "Überkauft" : (mkt?.rsi ?? 50) < 30 ? "Überverkauft" : "Neutral"}
                </div>
              </div>
              <div className="card-gold">
                <div className="text-xs text-gray-500 mb-1">ADX (14)</div>
                <div className={`font-black text-2xl ${(mkt?.adx ?? 20) > 25 ? "text-emerald-400" : "text-yellow-400"}`}>
                  {(mkt?.adx ?? 0).toFixed(1)}
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  {(mkt?.adx ?? 20) > 25 ? "Trend stark" : "Trend schwach"}
                </div>
              </div>
              <div className="card-gold">
                <div className="text-xs text-gray-500 mb-1">MACD</div>
                <div className={`font-black text-2xl ${(mkt?.macd ?? 0) > 0 ? "text-emerald-400" : "text-red-400"}`}>
                  {(mkt?.macd ?? 0).toFixed(3)}
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  {(mkt?.macd ?? 0) > 0 ? "▲ Bullish" : "▼ Bearish"}
                </div>
              </div>
              <div className="card-gold">
                <div className="text-xs text-gray-500 mb-1">Signal Score</div>
                <div className="mt-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className={`font-black text-2xl ${
                      (mkt?.signalScore ?? 0) >= 75 ? "text-emerald-400" :
                      (mkt?.signalScore ?? 0) >= 55 ? "text-yellow-400" : "text-red-400"
                    }`}>{mkt?.signalScore ?? 0}</span>
                    <span className="text-gray-500 text-sm">/100</span>
                  </div>
                  <div className="h-2 rounded-full overflow-hidden" style={{ background: "#1f2937" }}>
                    <div className="h-full rounded-full transition-all duration-500" style={{
                      width: `${mkt?.signalScore ?? 0}%`,
                      background: (mkt?.signalScore ?? 0) >= 75 ? "linear-gradient(90deg,#10b981,#059669)" :
                                  (mkt?.signalScore ?? 0) >= 55 ? "linear-gradient(90deg,#f59e0b,#d97706)" :
                                  "linear-gradient(90deg,#ef4444,#b91c1c)"
                    }}></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Open Trades */}
            <OpenTrades
              trades={status?.openTrades ?? []}
              goldPrice={mkt?.price ?? 2345}
              onClose={handleCloseTrade}
              onPartial={handlePartialClose}
              onModify={handleModifyTrade}
            />

            {/* Recent Logs */}
            <div className="card" style={{ padding: 0 }}>
              <div className="px-4 py-3 font-bold text-white" style={{ borderBottom: "1px solid #1f2937" }}>
                🔔 Letzte Aktivitäten
              </div>
              <div style={{ maxHeight: 300, overflowY: "auto" }}>
                {(status?.recentLogs ?? []).map((log) => {
                  const colors: Record<string, string> = { INFO: "#60a5fa", WARN: "#f59e0b", ERROR: "#ef4444" };
                  return (
                    <div key={log.id} className="flex items-start gap-3 px-4 py-2" style={{ borderBottom: "1px solid #0d1117" }}>
                      <span className="text-xs px-1.5 py-0.5 rounded font-bold flex-shrink-0" style={{
                        background: `${colors[log.level] ?? "#60a5fa"}20`,
                        color: colors[log.level] ?? "#60a5fa"
                      }}>{log.level}</span>
                      <span className="text-xs text-gray-300 flex-1">{log.message}</span>
                      <span className="text-xs text-gray-600 flex-shrink-0 font-mono">
                        {log.createdAt ? new Date(log.createdAt).toLocaleTimeString("de-AT") : ""}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ───── MARKET ANALYSIS TAB ───── */}
        {tab === "market" && mkt && (
          <MarketPanel
            snapshots={snapshots}
            currentPrice={mkt.price}
            rsi={mkt.rsi}
            adx={mkt.adx}
            atr={mkt.atr}
            macd={mkt.macd}
            ema20={mkt.ema20}
            ema50={mkt.ema50}
            ema200={mkt.ema200}
            signalScore={mkt.signalScore}
            bbUpper={mkt.bbUpper}
            bbLower={mkt.bbLower}
            volume={mkt.volume}
            relativeVolume={mkt.relativeVolume}
          />
        )}

        {/* ───── PERFORMANCE TAB ───── */}
        {tab === "performance" && performance && (
          <PerformancePanel
            summary={performance.summary}
            equityData={performance.equityData}
            byPhase={performance.byPhase}
            byExit={performance.byExit}
            byWeekday={performance.byWeekday}
            byHour={performance.byHour}
            bySession={performance.bySession}
            recentTrades={performance.recentTrades}
            adaptive={performance.adaptive}
          />
        )}

        {/* ───── TRADE HISTORY TAB ───── */}
        {tab === "history" && (
          <div className="card" style={{ padding: 0 }}>
            <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: "1px solid #1f2937" }}>
              <div className="font-bold text-white">📋 Trade Historie (letzte 100)</div>
              <button className="btn-outline text-xs py-1.5 px-3" onClick={fetchHistory}>🔄 Laden</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-gray-500 font-bold uppercase" style={{ borderBottom: "1px solid #1f2937" }}>
                    <th className="text-left px-3 py-2">Ticket</th>
                    <th className="text-left px-3 py-2">Dir</th>
                    <th className="text-right px-3 py-2">Entry</th>
                    <th className="text-right px-3 py-2">Exit</th>
                    <th className="text-left px-3 py-2">Phase</th>
                    <th className="text-right px-3 py-2">Score</th>
                    <th className="text-right px-3 py-2">Lots</th>
                    <th className="text-left px-3 py-2">Exit Grund</th>
                    <th className="text-right px-3 py-2">Pips</th>
                    <th className="text-right px-3 py-2">P&L ($)</th>
                    <th className="text-right px-3 py-2">Dauer</th>
                    <th className="text-left px-3 py-2">Geöffnet</th>
                  </tr>
                </thead>
                <tbody>
                  {historyTrades.map((t) => (
                    <tr key={t.id} className="trade-row">
                      <td className="px-3 py-2 font-mono text-gray-400">{t.ticketId?.slice(-8) ?? "–"}</td>
                      <td className="px-3 py-2">
                        <span className={`font-bold ${t.direction === "LONG" ? "text-emerald-400" : "text-red-400"}`}>
                          {t.direction === "LONG" ? "▲" : "▼"} {t.direction}
                        </span>
                      </td>
                      <td className="px-3 py-2 text-right font-mono text-gray-300">{t.entryPrice?.toFixed(2)}</td>
                      <td className="px-3 py-2 text-right font-mono text-gray-300">{"exitPrice" in t ? (t as unknown as { exitPrice: number | null }).exitPrice?.toFixed(2) ?? "–" : "–"}</td>
                      <td className="px-3 py-2 text-gray-400">{t.marketPhase ?? "–"}</td>
                      <td className="px-3 py-2 text-right">
                        <span className={`font-bold ${(t.signalScore ?? 0) >= 75 ? "text-emerald-400" : "text-yellow-400"}`}>
                          {t.signalScore ?? "–"}
                        </span>
                      </td>
                      <td className="px-3 py-2 text-right text-gray-300">{t.lotSize?.toFixed(2)}</td>
                      <td className="px-3 py-2 text-gray-400 font-mono">{"exitReason" in t ? (t as unknown as { exitReason: string | null }).exitReason?.replace("_", " ") ?? "–" : "–"}</td>
                      <td className="px-3 py-2 text-right font-bold">
                        {"profitPips" in t ? (() => {
                          const pp = (t as unknown as { profitPips: number | null }).profitPips;
                          return <span className={pp != null && pp >= 0 ? "text-emerald-400" : "text-red-400"}>{pp != null ? `${pp > 0 ? "+" : ""}${pp.toFixed(1)}` : "–"}</span>;
                        })() : "–"}
                      </td>
                      <td className="px-3 py-2 text-right font-bold">
                        {"profitUsd" in t ? (() => {
                          const pu = (t as unknown as { profitUsd: number | null }).profitUsd;
                          return <span className={pu != null && pu >= 0 ? "text-emerald-400" : "text-red-400"}>{pu != null ? `${pu > 0 ? "+" : ""}$${Math.abs(pu).toFixed(2)}` : "–"}</span>;
                        })() : "–"}
                      </td>
                      <td className="px-3 py-2 text-right text-gray-400">
                        {"holdingMinutes" in t ? `${(t as unknown as { holdingMinutes: number | null }).holdingMinutes ?? 0}m` : "–"}
                      </td>
                      <td className="px-3 py-2 text-gray-500 font-mono">
                        {t.openedAt ? new Date(t.openedAt).toLocaleDateString("de-AT") : "–"}
                      </td>
                    </tr>
                  ))}
                  {historyTrades.length === 0 && (
                    <tr>
                      <td colSpan={12} className="text-center py-8 text-gray-500">Keine abgeschlossenen Trades</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ───── SETTINGS TAB ───── */}
        {tab === "settings" && (
          <SettingsPanel settings={settings} onSave={handleSaveSettings} />
        )}

        {/* ───── LOGS TAB ───── */}
        {tab === "logs" && (
          <LogsPanel logs={logs} onRefresh={fetchLogs} />
        )}
      </main>

      {/* Footer */}
      <footer className="mt-8 pb-4 text-center text-xs text-gray-700">
        🥇 GOLD BOT v3.0 · XAUUSD Professional Trading System · Zeitzone: Europe/Vienna
        <br />
        ⚠️ Trading birgt erhebliche Verlustrisiken. Diese Software dient nur zu Bildungszwecken.
      </footer>
    </div>
  );
}
