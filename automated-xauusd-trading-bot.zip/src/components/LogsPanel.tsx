"use client";
import { formatDateTime } from "@/lib/utils";

interface LogEntry {
  id: number;
  level: string;
  category: string | null;
  message: string;
  createdAt: string | null;
}

interface Props {
  logs: LogEntry[];
  onRefresh: () => void;
}

const LEVEL_STYLES: Record<string, { bg: string; text: string; badge: string }> = {
  INFO: { bg: "rgba(59,130,246,0.05)", text: "#60a5fa", badge: "rgba(59,130,246,0.2)" },
  WARN: { bg: "rgba(245,158,11,0.05)", text: "#f59e0b", badge: "rgba(245,158,11,0.2)" },
  ERROR: { bg: "rgba(239,68,68,0.05)", text: "#ef4444", badge: "rgba(239,68,68,0.2)" },
};

const CAT_ICONS: Record<string, string> = {
  BOT: "🤖", TRADE: "📈", RISK: "🛡️", API: "🔌", SIGNAL: "🎯",
  ADAPT: "🧠", LEARN: "📚", TELEGRAM: "📱", SYSTEM: "⚙️",
};

export default function LogsPanel({ logs, onRefresh }: Props) {
  return (
    <div className="card" style={{ padding: 0 }}>
      <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: "1px solid #1f2937" }}>
        <div className="font-bold text-white">📋 System Log</div>
        <div className="flex items-center gap-3">
          <div className="flex gap-2">
            {["INFO", "WARN", "ERROR"].map((l) => (
              <span key={l} className="text-xs px-2 py-0.5 rounded font-bold" style={{
                background: LEVEL_STYLES[l]?.badge,
                color: LEVEL_STYLES[l]?.text,
                border: `1px solid ${LEVEL_STYLES[l]?.text}40`
              }}>
                {l}
              </span>
            ))}
          </div>
          <button className="btn-outline text-xs py-1.5 px-3" onClick={onRefresh}>🔄 Refresh</button>
        </div>
      </div>

      <div style={{ maxHeight: 600, overflowY: "auto" }}>
        {logs.length === 0 ? (
          <div className="text-center py-12 text-gray-500">Keine Logs vorhanden</div>
        ) : (
          logs.map((log) => {
            const style = LEVEL_STYLES[log.level] ?? LEVEL_STYLES.INFO;
            const icon = CAT_ICONS[log.category ?? ""] ?? "ℹ️";
            return (
              <div
                key={log.id}
                className="flex items-start gap-3 px-4 py-2.5 transition-all"
                style={{ background: style.bg, borderBottom: "1px solid #0d1117" }}
              >
                <span className="text-base mt-0.5 flex-shrink-0">{icon}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="text-xs font-bold px-1.5 py-0.5 rounded" style={{ background: style.badge, color: style.text }}>
                      {log.level}
                    </span>
                    {log.category && (
                      <span className="text-xs text-gray-500 font-mono">[{log.category}]</span>
                    )}
                    <span className="text-xs text-gray-600">{formatDateTime(log.createdAt)}</span>
                  </div>
                  <div className="text-sm text-gray-200">{log.message}</div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
