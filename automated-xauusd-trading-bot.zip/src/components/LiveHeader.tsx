"use client";
import { useState, useEffect } from "react";
import { formatDateTime, formatPrice } from "@/lib/utils";

interface HeaderProps {
  price: number;
  spread: number;
  bid: number;
  ask: number;
  botActive: boolean;
  botMode: string;
  account: string;
  equity: number;
  balance: number;
  drawdown: number;
  openPositions: number;
  signalScore: number;
  marketPhase: string;
  trendDirection: string;
  atr: number;
  onToggleBot: () => void;
  onPause: () => void;
  onCloseAll: () => void;
}

export default function LiveHeader({
  price, spread, bid, ask, botActive, botMode, account, equity, balance,
  drawdown, openPositions, signalScore, marketPhase, trendDirection, atr,
  onToggleBot, onPause, onCloseAll,
}: HeaderProps) {
  const [now, setNow] = useState(new Date());
  const [prevPrice, setPrevPrice] = useState(price);
  const [priceUp, setPriceUp] = useState<boolean | null>(null);

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (price !== prevPrice) {
      setPriceUp(price > prevPrice);
      setPrevPrice(price);
    }
  }, [price, prevPrice]);

  const scoreColor = signalScore >= 75 ? "text-emerald-400" : signalScore >= 55 ? "text-yellow-400" : "text-red-400";
  const phaseColor =
    marketPhase === "TREND" ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" :
    marketPhase === "BREAKOUT" ? "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" :
    "bg-blue-500/20 text-blue-400 border-blue-500/30";

  return (
    <header className="sticky top-0 z-50" style={{ background: "#060810", borderBottom: "1px solid #1f2937" }}>
      {/* Top bar */}
      <div className="flex items-center justify-between px-4 py-2" style={{ borderBottom: "1px solid #1a2030" }}>
        <div className="flex items-center gap-3">
          <div className="text-2xl">🥇</div>
          <div>
            <div className="font-black text-lg tracking-tight" style={{ color: "#f5c518", lineHeight: 1.1 }}>
              GOLD BOT <span className="text-xs font-normal text-gray-500 ml-1">XAUUSD</span>
            </div>
            <div className="text-xs text-gray-500">Professional Trading System v3.0</div>
          </div>
          <div className={`live-badge ml-2 ${botActive ? "" : "opacity-40"}`}>
            {botActive ? "● LIVE" : "■ PAUSE"}
          </div>
        </div>

        {/* Gold Price – Center */}
        <div className="flex flex-col items-center">
          <div className="text-xs text-gray-500 font-semibold tracking-wider">XAUUSD</div>
          <div className={`font-black text-3xl price-ticker transition-colors duration-300 ${
            priceUp === true ? "text-emerald-400" : priceUp === false ? "text-red-400" : ""
          }`} style={{ color: priceUp === null ? "#f5c518" : undefined }}>
            {formatPrice(price, 2)}
          </div>
          <div className="flex gap-3 text-xs text-gray-500 mt-0.5">
            <span>B: <span className="text-red-400">{formatPrice(bid, 2)}</span></span>
            <span>A: <span className="text-emerald-400">{formatPrice(ask, 2)}</span></span>
            <span>Spread: <span className="text-gray-300">{formatPrice(spread * 10, 1)} Pip</span></span>
          </div>
        </div>

        {/* Right info */}
        <div className="flex items-center gap-6 text-right">
          <div>
            <div className="text-xs text-gray-500">EQUITY</div>
            <div className="font-bold text-white">${equity.toFixed(2)}</div>
          </div>
          <div>
            <div className="text-xs text-gray-500">BALANCE</div>
            <div className="font-bold text-gray-300">${balance.toFixed(2)}</div>
          </div>
          <div>
            <div className="text-xs text-gray-500">DRAWDOWN</div>
            <div className={`font-bold ${drawdown > 5 ? "text-red-400" : drawdown > 2 ? "text-yellow-400" : "text-emerald-400"}`}>
              {drawdown.toFixed(2)}%
            </div>
          </div>
          <div>
            <div className="text-xs text-gray-500">POSITIONS</div>
            <div className="font-bold text-white">{openPositions}</div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="flex items-center justify-between px-4 py-2 gap-4">
        {/* Indicators */}
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-gray-500">ATR:</span>
            <span className="text-xs font-bold text-white">{formatPrice(atr, 1)}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-gray-500">Phase:</span>
            <span className={`text-xs font-bold px-2 py-0.5 rounded border ${phaseColor}`}>{marketPhase}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-gray-500">Trend:</span>
            <span className={`text-xs font-bold px-2 py-0.5 rounded border ${
              trendDirection === "LONG" ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" :
              trendDirection === "SHORT" ? "bg-red-500/20 text-red-400 border-red-500/30" :
              "bg-gray-500/20 text-gray-400 border-gray-500/30"
            }`}>{trendDirection === "LONG" ? "▲ LONG" : trendDirection === "SHORT" ? "▼ SHORT" : "↔ NEUTRAL"}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-gray-500">Signal:</span>
            <div className="flex items-center gap-1">
              <div className="w-24 h-2 rounded-full overflow-hidden" style={{ background: "#1f2937" }}>
                <div className="h-full rounded-full transition-all duration-500" style={{
                  width: `${signalScore}%`,
                  background: signalScore >= 75 ? "linear-gradient(90deg,#10b981,#059669)" :
                              signalScore >= 55 ? "linear-gradient(90deg,#f59e0b,#d97706)" :
                              "linear-gradient(90deg,#ef4444,#b91c1c)"
                }}></div>
              </div>
              <span className={`text-xs font-black ${scoreColor}`}>{signalScore}/100</span>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-gray-500">Zeit:</span>
            <span className="text-xs text-gray-300 font-mono">{formatDateTime(now)}</span>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <button className="btn-outline text-xs py-1.5 px-3" onClick={onPause}>
            {botActive ? "⏸ Pause" : "▶ Resume"}
          </button>
          <button className="btn-red text-xs py-1.5 px-3" onClick={onCloseAll}>
            ✕ Alle schließen
          </button>
          <button className={`text-xs py-1.5 px-3 rounded-lg font-bold transition-all ${
            botActive
              ? "bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/30"
              : "bg-red-500/20 border border-red-500/40 text-red-400 hover:bg-red-500/30"
          }`} onClick={onToggleBot}>
            <span className="status-dot mr-1.5 inline-block" style={{
              background: botActive ? "#10b981" : "#6b7280",
              boxShadow: botActive ? "0 0 6px #10b981" : "none",
              animation: botActive ? "pulse-green 2s infinite" : "none"
            }}></span>
            {botActive ? "BOT AKTIV" : "BOT INAKTIV"}
          </button>
        </div>
      </div>
    </header>
  );
}
