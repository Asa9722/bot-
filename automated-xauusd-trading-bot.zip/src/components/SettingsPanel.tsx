"use client";
import { useState } from "react";

type Settings = Record<string, string>;

interface Props {
  settings: Settings;
  onSave: (updates: Settings) => Promise<void>;
}

function Toggle({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <input
      type="checkbox"
      className="toggle"
      checked={value === "true"}
      onChange={(e) => onChange(e.target.checked ? "true" : "false")}
    />
  );
}

function NumberInput({ value, onChange, min, max, step = 0.1 }: {
  value: string; onChange: (v: string) => void; min?: number; max?: number; step?: number;
}) {
  return (
    <input
      type="number"
      className="input-dark"
      value={value}
      min={min}
      max={max}
      step={step}
      onChange={(e) => onChange(e.target.value)}
    />
  );
}

function SelectInput({ value, onChange, options }: {
  value: string; onChange: (v: string) => void; options: { value: string; label: string }[];
}) {
  return (
    <select
      className="input-dark"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      style={{ background: "#060810" }}
    >
      {options.map((o) => (
        <option key={o.value} value={o.value}>{o.label}</option>
      ))}
    </select>
  );
}

function Row({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between py-2.5" style={{ borderBottom: "1px solid #1a2030" }}>
      <div>
        <div className="text-sm text-gray-200">{label}</div>
        {hint && <div className="text-xs text-gray-500 mt-0.5">{hint}</div>}
      </div>
      <div className="ml-4 min-w-[120px]">{children}</div>
    </div>
  );
}

function Section({ title, icon, children }: { title: string; icon: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(true);
  return (
    <div className="card mb-4">
      <button
        className="flex items-center justify-between w-full text-left"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-2">
          <span className="text-lg">{icon}</span>
          <span className="font-bold text-white">{title}</span>
        </div>
        <span className="text-gray-500 text-sm">{open ? "▲" : "▼"}</span>
      </button>
      {open && <div className="mt-3">{children}</div>}
    </div>
  );
}

export default function SettingsPanel({ settings, onSave }: Props) {
  const [local, setLocal] = useState<Settings>({ ...settings });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const set = (key: string, value: string) => setLocal((p) => ({ ...p, [key]: value }));
  const get = (key: string, fallback = "") => local[key] ?? fallback;

  const handleSave = async () => {
    setSaving(true);
    await onSave(local);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="max-w-3xl mx-auto">
      {/* Save Button */}
      <div className="flex items-center justify-between mb-4">
        <div className="text-sm text-gray-400">Alle Einstellungen werden sofort gespeichert und angewendet.</div>
        <button className="btn-gold px-6 py-2.5" onClick={handleSave} disabled={saving}>
          {saving ? "⏳ Speichern..." : saved ? "✅ Gespeichert!" : "💾 Speichern"}
        </button>
      </div>

      {/* BOT CONTROL */}
      <Section title="Bot-Steuerung" icon="🤖">
        <Row label="Bot aktiv" hint="Hauptschalter für alle Trading-Aktivitäten">
          <Toggle value={get("bot_active", "true")} onChange={(v) => set("bot_active", v)} />
        </Row>
        <Row label="Bot Modus" hint="LIVE = echter Account, PAPER = Simulation, PAUSE = pausiert">
          <SelectInput value={get("bot_mode", "PAPER")} onChange={(v) => set("bot_mode", v)} options={[
            { value: "LIVE", label: "🔴 LIVE" },
            { value: "PAPER", label: "📄 PAPER" },
            { value: "PAUSE", label: "⏸ PAUSE" },
          ]} />
        </Row>
        <Row label="Zeitzone">
          <SelectInput value={get("timezone", "Europe/Vienna")} onChange={(v) => set("timezone", v)} options={[
            { value: "Europe/Vienna", label: "Europe/Vienna (AT)" },
            { value: "Europe/London", label: "Europe/London" },
            { value: "America/New_York", label: "America/New_York" },
            { value: "UTC", label: "UTC" },
          ]} />
        </Row>
      </Section>

      {/* STRATEGY */}
      <Section title="Strategie & Indikatoren" icon="📊">
        <Row label="Signal Score Minimum" hint="0-100 | Nur Trades mit höherem Score werden eröffnet">
          <NumberInput value={get("signal_score_min", "65")} onChange={(v) => set("signal_score_min", v)} min={30} max={95} step={1} />
        </Row>
        <Row label="RSI Periode">
          <NumberInput value={get("rsi_period", "14")} onChange={(v) => set("rsi_period", v)} min={5} max={50} step={1} />
        </Row>
        <Row label="RSI Überverkauft">
          <NumberInput value={get("rsi_oversold", "30")} onChange={(v) => set("rsi_oversold", v)} min={10} max={45} step={1} />
        </Row>
        <Row label="RSI Überkauft">
          <NumberInput value={get("rsi_overbought", "70")} onChange={(v) => set("rsi_overbought", v)} min={55} max={90} step={1} />
        </Row>
        <Row label="EMA Fast">
          <NumberInput value={get("ema_fast", "20")} onChange={(v) => set("ema_fast", v)} min={5} max={50} step={1} />
        </Row>
        <Row label="EMA Mid">
          <NumberInput value={get("ema_mid", "50")} onChange={(v) => set("ema_mid", v)} min={20} max={100} step={1} />
        </Row>
        <Row label="EMA Slow">
          <NumberInput value={get("ema_slow", "100")} onChange={(v) => set("ema_slow", v)} min={50} max={200} step={1} />
        </Row>
        <Row label="EMA Trend (200)">
          <NumberInput value={get("ema_trend", "200")} onChange={(v) => set("ema_trend", v)} min={100} max={500} step={1} />
        </Row>
        <Row label="ADX Minimum" hint="Mindest-Trendstärke für Einstieg">
          <NumberInput value={get("adx_minimum", "20")} onChange={(v) => set("adx_minimum", v)} min={10} max={50} step={1} />
        </Row>
        <Row label="ATR Periode">
          <NumberInput value={get("atr_period", "14")} onChange={(v) => set("atr_period", v)} min={5} max={50} step={1} />
        </Row>
        <Row label="MACD Fast">
          <NumberInput value={get("macd_fast", "12")} onChange={(v) => set("macd_fast", v)} min={3} max={30} step={1} />
        </Row>
        <Row label="MACD Slow">
          <NumberInput value={get("macd_slow", "26")} onChange={(v) => set("macd_slow", v)} min={10} max={60} step={1} />
        </Row>
        <Row label="MACD Signal">
          <NumberInput value={get("macd_signal", "9")} onChange={(v) => set("macd_signal", v)} min={3} max={20} step={1} />
        </Row>
        <Row label="Trendfilter aktiv" hint="Nur Trades in Richtung des Haupttrends">
          <Toggle value={get("trend_filter", "true")} onChange={(v) => set("trend_filter", v)} />
        </Row>
        <Row label="Volumenfilter aktiv" hint="Mindest-Volumen für Einstieg erforderlich">
          <Toggle value={get("volume_filter", "true")} onChange={(v) => set("volume_filter", v)} />
        </Row>
        <Row label="15M Gewichtung (%)" hint="Gewicht des 15-Minuten-Timeframes">
          <NumberInput value={get("tf_15m_weight", "25")} onChange={(v) => set("tf_15m_weight", v)} min={0} max={100} step={5} />
        </Row>
        <Row label="1H Gewichtung (%)">
          <NumberInput value={get("tf_1h_weight", "45")} onChange={(v) => set("tf_1h_weight", v)} min={0} max={100} step={5} />
        </Row>
        <Row label="4H Gewichtung (%)">
          <NumberInput value={get("tf_4h_weight", "30")} onChange={(v) => set("tf_4h_weight", v)} min={0} max={100} step={5} />
        </Row>
      </Section>

      {/* RISK – TRADE LEVEL */}
      <Section title="Risikomanagement – Trade Ebene" icon="🛡️">
        <Row label="Stop Loss Typ" hint="Basis für SL-Berechnung">
          <SelectInput value={get("sl_type", "ATR")} onChange={(v) => set("sl_type", v)} options={[
            { value: "ATR", label: "ATR-basiert" },
            { value: "FIXED", label: "Fest (Pips)" },
            { value: "PERCENT", label: "Prozentual" },
            { value: "DYNAMIC", label: "Dynamisch" },
          ]} />
        </Row>
        <Row label="SL Fest (Pips)">
          <NumberInput value={get("sl_fixed_pips", "200")} onChange={(v) => set("sl_fixed_pips", v)} min={10} max={1000} step={10} />
        </Row>
        <Row label="SL Prozent (%)">
          <NumberInput value={get("sl_percent", "1.5")} onChange={(v) => set("sl_percent", v)} min={0.1} max={5} step={0.1} />
        </Row>
        <Row label="SL ATR Multiplikator">
          <NumberInput value={get("sl_atr_multiplier", "2.0")} onChange={(v) => set("sl_atr_multiplier", v)} min={0.5} max={5} step={0.1} />
        </Row>
        <Row label="TP Typ">
          <SelectInput value={get("tp_type", "DYNAMIC")} onChange={(v) => set("tp_type", v)} options={[
            { value: "DYNAMIC", label: "Dynamisch" },
            { value: "ATR", label: "ATR-basiert" },
            { value: "FIXED", label: "Fest (Pips)" },
            { value: "RISK_REWARD", label: "Risk:Reward" },
          ]} />
        </Row>
        <Row label="TP ATR Multiplikator">
          <NumberInput value={get("tp_atr_multiplier", "3.0")} onChange={(v) => set("tp_atr_multiplier", v)} min={0.5} max={10} step={0.1} />
        </Row>
        <Row label="Trailing Stop aktiv">
          <Toggle value={get("trailing_stop", "true")} onChange={(v) => set("trailing_stop", v)} />
        </Row>
        <Row label="Trailing Typ">
          <SelectInput value={get("trailing_type", "ATR")} onChange={(v) => set("trailing_type", v)} options={[
            { value: "ATR", label: "ATR-basiert" },
            { value: "STATIC", label: "Statisch" },
          ]} />
        </Row>
        <Row label="Trailing Start (%)" hint="Ab welchem Gewinn % startet der Trailing Stop">
          <NumberInput value={get("trailing_start_percent", "1.0")} onChange={(v) => set("trailing_start_percent", v)} min={0.1} max={5} step={0.1} />
        </Row>
        <Row label="Trailing Abstand (ATR)">
          <NumberInput value={get("trailing_distance_atr", "1.5")} onChange={(v) => set("trailing_distance_atr", v)} min={0.5} max={5} step={0.1} />
        </Row>
        <Row label="Break-Even aktiv">
          <Toggle value={get("break_even", "true")} onChange={(v) => set("break_even", v)} />
        </Row>
        <Row label="Break-Even Trigger (%)">
          <NumberInput value={get("break_even_trigger_percent", "0.5")} onChange={(v) => set("break_even_trigger_percent", v)} min={0.1} max={3} step={0.1} />
        </Row>
        <Row label="Teilverkauf aktiv">
          <Toggle value={get("partial_close", "true")} onChange={(v) => set("partial_close", v)} />
        </Row>
        <Row label="Teilverkauf Prozent (%)">
          <NumberInput value={get("partial_close_percent", "50")} onChange={(v) => set("partial_close_percent", v)} min={10} max={90} step={5} />
        </Row>
        <Row label="Teilverkauf Trigger (%)">
          <NumberInput value={get("partial_trigger_percent", "1.0")} onChange={(v) => set("partial_trigger_percent", v)} min={0.1} max={5} step={0.1} />
        </Row>
        <Row label="Momentum Exit aktiv" hint="Früher aussteigen bei schwindendem Momentum">
          <Toggle value={get("momentum_exit", "true")} onChange={(v) => set("momentum_exit", v)} />
        </Row>
        <Row label="Dynamischer TP aktiv">
          <Toggle value={get("dynamic_tp", "true")} onChange={(v) => set("dynamic_tp", v)} />
        </Row>
      </Section>

      {/* RISK – ACCOUNT LEVEL */}
      <Section title="Risikomanagement – Konto Ebene" icon="💰">
        <Row label="Risiko pro Trade (%)" hint="% des Kontos, das pro Trade riskiert wird">
          <NumberInput value={get("risk_per_trade_percent", "1.0")} onChange={(v) => set("risk_per_trade_percent", v)} min={0.1} max={5} step={0.1} />
        </Row>
        <Row label="Risiko pro Serie (%)">
          <NumberInput value={get("risk_per_series_percent", "3.0")} onChange={(v) => set("risk_per_series_percent", v)} min={0.5} max={10} step={0.1} />
        </Row>
        <Row label="Max offene Trades">
          <NumberInput value={get("max_open_trades", "10")} onChange={(v) => set("max_open_trades", v)} min={1} max={30} step={1} />
        </Row>
        <Row label="Max Trades pro Stunde">
          <NumberInput value={get("max_trades_per_hour", "5")} onChange={(v) => set("max_trades_per_hour", v)} min={1} max={20} step={1} />
        </Row>
        <Row label="Max Trades pro Tag">
          <NumberInput value={get("max_trades_per_day", "20")} onChange={(v) => set("max_trades_per_day", v)} min={1} max={100} step={1} />
        </Row>
        <Row label="Max Tagesverlust (%)">
          <NumberInput value={get("max_daily_loss_percent", "5.0")} onChange={(v) => set("max_daily_loss_percent", v)} min={0.5} max={20} step={0.5} />
        </Row>
        <Row label="Max Wochenverlust (%)">
          <NumberInput value={get("max_weekly_loss_percent", "10.0")} onChange={(v) => set("max_weekly_loss_percent", v)} min={1} max={30} step={0.5} />
        </Row>
        <Row label="Max Drawdown (%)">
          <NumberInput value={get("max_drawdown_percent", "15.0")} onChange={(v) => set("max_drawdown_percent", v)} min={1} max={50} step={0.5} />
        </Row>
        <Row label="Equity Schutz (%)">
          <NumberInput value={get("equity_protection_percent", "80.0")} onChange={(v) => set("equity_protection_percent", v)} min={50} max={99} step={1} />
        </Row>
        <Row label="Max LONG Positionen">
          <NumberInput value={get("max_long_positions", "7")} onChange={(v) => set("max_long_positions", v)} min={1} max={20} step={1} />
        </Row>
        <Row label="Max SHORT Positionen">
          <NumberInput value={get("max_short_positions", "7")} onChange={(v) => set("max_short_positions", v)} min={1} max={20} step={1} />
        </Row>
      </Section>

      {/* PROTECTION */}
      <Section title="Schutzfunktionen" icon="🔒">
        <Row label="Pause nach X Verlusten" hint="Bot pausiert nach dieser Anzahl aufeinanderfolgender Verluste">
          <NumberInput value={get("pause_after_losses", "3")} onChange={(v) => set("pause_after_losses", v)} min={1} max={10} step={1} />
        </Row>
        <Row label="Pause bei hoher Volatilität">
          <Toggle value={get("pause_high_volatility", "true")} onChange={(v) => set("pause_high_volatility", v)} />
        </Row>
        <Row label="News Stop Modus" hint="Keine Trades bei wichtigen Wirtschaftsnachrichten">
          <Toggle value={get("news_stop", "true")} onChange={(v) => set("news_stop", v)} />
        </Row>
        <Row label="Max Spread (Pips)">
          <NumberInput value={get("max_spread_pips", "30")} onChange={(v) => set("max_spread_pips", v)} min={5} max={100} step={1} />
        </Row>
        <Row label="Max Slippage (Pips)">
          <NumberInput value={get("max_slippage_pips", "10")} onChange={(v) => set("max_slippage_pips", v)} min={1} max={50} step={1} />
        </Row>
      </Section>

      {/* MULTI-TRADE */}
      <Section title="Multi-Trade Management" icon="⚡">
        <Row label="Multi-Entry Modus" hint="Mehrere Positionen in gleicher Richtung erlaubt">
          <Toggle value={get("multi_entry", "true")} onChange={(v) => set("multi_entry", v)} />
        </Row>
        <Row label="Hedging erlaubt" hint="Long und Short gleichzeitig aktiv">
          <Toggle value={get("hedging_allowed", "false")} onChange={(v) => set("hedging_allowed", v)} />
        </Row>
        <Row label="Min Abstand zwischen Entries (Pips)">
          <NumberInput value={get("min_entry_distance_pips", "50")} onChange={(v) => set("min_entry_distance_pips", v)} min={0} max={500} step={10} />
        </Row>
        <Row label="Skalierungsfaktor" hint="Lotgröße-Reduktion bei gestaffelten Entries (0.75 = 75% des vorherigen)">
          <NumberInput value={get("scaling_factor", "0.75")} onChange={(v) => set("scaling_factor", v)} min={0.1} max={2} step={0.05} />
        </Row>
        <Row label="Positions-Multiplikator">
          <NumberInput value={get("position_multiplier", "1.0")} onChange={(v) => set("position_multiplier", v)} min={0.1} max={5} step={0.1} />
        </Row>
      </Section>

      {/* ADAPTIVE LEARNING */}
      <Section title="Lern- & Adaptionssystem" icon="🧠">
        <Row label="Adaptiver Modus aktiv" hint="Bot optimiert Parameter selbstständig basierend auf Ergebnissen">
          <Toggle value={get("adaptive_mode", "true")} onChange={(v) => set("adaptive_mode", v)} />
        </Row>
        <Row label="Lernintervall (Trades)" hint="Alle X abgeschlossenen Trades werden Parameter überprüft">
          <NumberInput value={get("learn_interval_trades", "50")} onChange={(v) => set("learn_interval_trades", v)} min={10} max={500} step={10} />
        </Row>
        <Row label="Auto Parameter-Anpassung">
          <Toggle value={get("auto_param_adjust", "true")} onChange={(v) => set("auto_param_adjust", v)} />
        </Row>
      </Section>

      {/* TELEGRAM */}
      <Section title="Telegram Benachrichtigungen" icon="📱">
        <Row label="Telegram aktiv">
          <Toggle value={get("telegram_enabled", "false")} onChange={(v) => set("telegram_enabled", v)} />
        </Row>
        <Row label="Bot Token">
          <input
            type="password"
            className="input-dark"
            value={get("telegram_bot_token")}
            onChange={(e) => set("telegram_bot_token", e.target.value)}
            placeholder="123456:ABC-DEF..."
          />
        </Row>
        <Row label="Chat ID">
          <input
            type="text"
            className="input-dark"
            value={get("telegram_chat_id")}
            onChange={(e) => set("telegram_chat_id", e.target.value)}
            placeholder="-1001234567890"
          />
        </Row>
        <div className="mt-3 p-3 rounded-lg text-xs text-gray-400" style={{ background: "#0a0d13", border: "1px solid #1f2937" }}>
          <div className="font-bold text-gray-300 mb-2">📨 Telegram Befehle:</div>
          <div className="grid grid-cols-4 gap-1 font-mono">
            {["/status", "/performance", "/open", "/close", "/pause", "/resume", "/settings", "/risk"].map((cmd) => (
              <span key={cmd} className="px-2 py-1 rounded text-center" style={{ background: "#1f2937", color: "#f5c518" }}>{cmd}</span>
            ))}
          </div>
        </div>
      </Section>

      {/* MT5 Account */}
      <Section title="MetaTrader 5 Verbindung" icon="🔌">
        <Row label="Account Nummer">
          <input type="text" className="input-dark" value={get("mt5_account")} onChange={(e) => set("mt5_account", e.target.value)} />
        </Row>
        <Row label="Server">
          <input type="text" className="input-dark" value={get("mt5_server")} onChange={(e) => set("mt5_server", e.target.value)} />
        </Row>
        <Row label="Konto Balance ($)">
          <NumberInput value={get("account_balance", "10000")} onChange={(v) => set("account_balance", v)} min={100} max={10000000} step={100} />
        </Row>
        <Row label="Konto Währung">
          <SelectInput value={get("account_currency", "USD")} onChange={(v) => set("account_currency", v)} options={[
            { value: "USD", label: "USD" },
            { value: "EUR", label: "EUR" },
            { value: "GBP", label: "GBP" },
          ]} />
        </Row>
        <div className="mt-3 p-3 rounded-lg" style={{ background: "rgba(245,197,24,0.05)", border: "1px solid rgba(245,197,24,0.2)" }}>
          <div className="text-xs text-yellow-500 font-bold mb-1">⚠️ Python Backend erforderlich</div>
          <div className="text-xs text-gray-400">
            Für echtes Trading benötigst du das Python-Backend mit MetaTrader5 API.
            Dieses Dashboard zeigt Echtzeit-Demo-Daten. Installiere das Python-Paket mit:
            <code className="block mt-1 p-2 rounded text-xs font-mono" style={{ background: "#0a0d13", color: "#f5c518" }}>
              pip install MetaTrader5 flask flask-socketio pandas numpy
            </code>
          </div>
        </div>
      </Section>

      <div className="flex justify-end mt-4 mb-8">
        <button className="btn-gold px-8 py-3 text-base" onClick={handleSave} disabled={saving}>
          {saving ? "⏳ Speichern..." : saved ? "✅ Alle Einstellungen gespeichert!" : "💾 Alle Einstellungen speichern"}
        </button>
      </div>
    </div>
  );
}
