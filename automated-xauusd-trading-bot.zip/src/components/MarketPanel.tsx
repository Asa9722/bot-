"use client";
import {
  LineChart, Line, AreaChart, Area, XAxis, YAxis, Tooltip,
  ResponsiveContainer, ReferenceLine, CartesianGrid,
} from "recharts";
import { formatPrice } from "@/lib/utils";

interface Snapshot {
  price: number;
  rsi: number | null;
  macd: number | null;
  atr: number | null;
  adx: number | null;
  ema20: number | null;
  ema50: number | null;
  ema200: number | null;
  bbUpper: number | null;
  bbLower: number | null;
  bbMiddle: number | null;
  stochK: number | null;
  stochD: number | null;
  volume: number | null;
  relativeVolume: number | null;
  signalScore: number | null;
  recordedAt: string | null;
}

interface Props {
  snapshots: Snapshot[];
  currentPrice: number;
  rsi: number;
  adx: number;
  atr: number;
  macd: number;
  ema20: number;
  ema50: number;
  ema200: number;
  signalScore: number;
  bbUpper: number;
  bbLower: number;
  volume: number;
  relativeVolume: number;
}

const TOOLTIP_STYLE = {
  background: "#0d1117",
  border: "1px solid #374151",
  borderRadius: 8,
  color: "#e5e7eb",
  fontSize: 11,
};

export default function MarketPanel({
  snapshots, currentPrice, rsi, adx, atr, macd,
  ema20, ema50, ema200, signalScore, bbUpper, bbLower, volume, relativeVolume
}: Props) {
  const chartData = snapshots.map((s, i) => ({
    i,
    price: s.price,
    ema20: s.ema20,
    ema50: s.ema50,
    ema200: s.ema200,
    bbUpper: s.bbUpper,
    bbLower: s.bbLower,
    bbMiddle: s.bbMiddle,
    rsi: s.rsi,
    macd: s.macd,
    adx: s.adx,
    stochK: s.stochK,
    stochD: s.stochD,
    vol: s.volume,
    relVol: s.relativeVolume,
    score: s.signalScore,
    time: s.recordedAt ? new Date(s.recordedAt).toLocaleTimeString("de-AT", { hour: "2-digit", minute: "2-digit" }) : "",
  }));

  const priceMin = Math.min(...chartData.map((d) => d.price)) - 5;
  const priceMax = Math.max(...chartData.map((d) => d.price)) + 5;

  const indicators = [
    { label: "RSI (14)", value: rsi.toFixed(1), color: rsi > 70 ? "#ef4444" : rsi < 30 ? "#10b981" : "#f5c518", note: rsi > 70 ? "Überkauft" : rsi < 30 ? "Überverkauft" : "Neutral" },
    { label: "ADX (14)", value: adx.toFixed(1), color: adx > 25 ? "#10b981" : "#f59e0b", note: adx > 25 ? "Trend stark" : "Trend schwach" },
    { label: "ATR (14)", value: atr.toFixed(2), color: "#60a5fa", note: "Volatilität" },
    { label: "MACD", value: macd.toFixed(3), color: macd > 0 ? "#10b981" : "#ef4444", note: macd > 0 ? "Bullish" : "Bearish" },
    { label: "EMA 20", value: formatPrice(ema20), color: "#a78bfa", note: "" },
    { label: "EMA 50", value: formatPrice(ema50), color: "#60a5fa", note: "" },
    { label: "EMA 200", value: formatPrice(ema200), color: "#f59e0b", note: "" },
    { label: "BB Upper", value: formatPrice(bbUpper), color: "#6b7280", note: "" },
    { label: "BB Lower", value: formatPrice(bbLower), color: "#6b7280", note: "" },
    { label: "Vol.Rel.", value: relativeVolume.toFixed(2) + "x", color: relativeVolume > 1.5 ? "#10b981" : "#6b7280", note: relativeVolume > 1.5 ? "Spike" : "Normal" },
  ];

  return (
    <div className="space-y-4">
      {/* Indicator Grid */}
      <div className="grid grid-cols-5 gap-2">
        {indicators.map((ind) => (
          <div key={ind.label} className="metric-card" style={{ borderTop: `2px solid ${ind.color}30` }}>
            <div className="text-xs text-gray-500 mb-1">{ind.label}</div>
            <div className="font-black text-lg" style={{ color: ind.color }}>{ind.value}</div>
            {ind.note && <div className="text-xs mt-0.5" style={{ color: ind.color, opacity: 0.7 }}>{ind.note}</div>}
          </div>
        ))}
      </div>

      {/* Price Chart */}
      <div className="card">
        <div className="flex items-center justify-between mb-3">
          <div className="font-bold text-white">XAUUSD Preisverlauf (2h)</div>
          <div className="font-black text-xl" style={{ color: "#f5c518" }}>{formatPrice(currentPrice, 2)}</div>
        </div>
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={chartData} margin={{ top: 5, right: 5, bottom: 0, left: 5 }}>
            <defs>
              <linearGradient id="goldGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#f5c518" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#f5c518" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="bbGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6b7280" stopOpacity={0.1} />
                <stop offset="95%" stopColor="#6b7280" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" />
            <XAxis dataKey="time" tick={{ fill: "#6b7280", fontSize: 10 }} tickLine={false} interval={19} />
            <YAxis domain={[priceMin, priceMax]} tick={{ fill: "#6b7280", fontSize: 10 }} tickLine={false} width={55} />
            <Tooltip contentStyle={TOOLTIP_STYLE} />
            <Area type="monotone" dataKey="bbUpper" stroke="#374151" strokeWidth={1} fill="none" strokeDasharray="3 3" dot={false} />
            <Area type="monotone" dataKey="bbLower" stroke="#374151" strokeWidth={1} fill="none" strokeDasharray="3 3" dot={false} />
            <Line type="monotone" dataKey="ema200" stroke="#f59e0b" strokeWidth={1.5} dot={false} strokeDasharray="4 2" />
            <Line type="monotone" dataKey="ema50" stroke="#60a5fa" strokeWidth={1.5} dot={false} />
            <Line type="monotone" dataKey="ema20" stroke="#a78bfa" strokeWidth={1.5} dot={false} />
            <Area type="monotone" dataKey="price" stroke="#f5c518" strokeWidth={2} fill="url(#goldGrad)" dot={false} />
          </AreaChart>
        </ResponsiveContainer>
        <div className="flex gap-4 mt-2 text-xs">
          <span style={{ color: "#f5c518" }}>● Preis</span>
          <span style={{ color: "#a78bfa" }}>● EMA 20</span>
          <span style={{ color: "#60a5fa" }}>● EMA 50</span>
          <span style={{ color: "#f59e0b" }}>● EMA 200</span>
          <span style={{ color: "#374151" }}>- - BB</span>
        </div>
      </div>

      {/* RSI + MACD + Stoch Row */}
      <div className="grid grid-cols-3 gap-4">
        {/* RSI */}
        <div className="card">
          <div className="font-bold text-sm text-white mb-2">RSI (14)</div>
          <ResponsiveContainer width="100%" height={100}>
            <LineChart data={chartData}>
              <YAxis domain={[0, 100]} hide />
              <Tooltip contentStyle={TOOLTIP_STYLE} />
              <ReferenceLine y={70} stroke="#ef4444" strokeDasharray="3 3" strokeWidth={1} />
              <ReferenceLine y={30} stroke="#10b981" strokeDasharray="3 3" strokeWidth={1} />
              <ReferenceLine y={50} stroke="#374151" strokeDasharray="3 3" strokeWidth={1} />
              <Line type="monotone" dataKey="rsi" stroke="#f5c518" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
          <div className="flex justify-between text-xs mt-1">
            <span className="text-red-400">OB: 70</span>
            <span className="font-bold text-white">{rsi.toFixed(1)}</span>
            <span className="text-emerald-400">OS: 30</span>
          </div>
        </div>

        {/* MACD */}
        <div className="card">
          <div className="font-bold text-sm text-white mb-2">MACD (12/26/9)</div>
          <ResponsiveContainer width="100%" height={100}>
            <LineChart data={chartData}>
              <YAxis hide />
              <Tooltip contentStyle={TOOLTIP_STYLE} />
              <ReferenceLine y={0} stroke="#374151" strokeWidth={1} />
              <Line type="monotone" dataKey="macd" stroke="#f5c518" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
          <div className="text-center text-xs mt-1">
            <span className={macd > 0 ? "text-emerald-400 font-bold" : "text-red-400 font-bold"}>
              {macd > 0 ? "▲ Bullish" : "▼ Bearish"} | {macd.toFixed(3)}
            </span>
          </div>
        </div>

        {/* ADX + Signal Score */}
        <div className="card">
          <div className="font-bold text-sm text-white mb-2">ADX / Signal Score</div>
          <ResponsiveContainer width="100%" height={100}>
            <LineChart data={chartData}>
              <YAxis domain={[0, 100]} hide />
              <Tooltip contentStyle={TOOLTIP_STYLE} />
              <ReferenceLine y={25} stroke="#f5c518" strokeDasharray="3 3" strokeWidth={1} />
              <Line type="monotone" dataKey="adx" stroke="#60a5fa" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="score" stroke="#f5c518" strokeWidth={1.5} dot={false} strokeDasharray="4 2" />
            </LineChart>
          </ResponsiveContainer>
          <div className="flex justify-between text-xs mt-1">
            <span className="text-blue-400">ADX: {adx.toFixed(1)}</span>
            <span className="text-yellow-400">Score: {signalScore}/100</span>
          </div>
        </div>
      </div>

      {/* Volume */}
      <div className="card">
        <div className="font-bold text-sm text-white mb-2">Volumen & Relative Stärke</div>
        <ResponsiveContainer width="100%" height={80}>
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="volGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#10b981" stopOpacity={0.5} />
                <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="time" hide />
            <YAxis hide />
            <Tooltip contentStyle={TOOLTIP_STYLE} />
            <Area type="monotone" dataKey="vol" stroke="#10b981" strokeWidth={1.5} fill="url(#volGrad)" dot={false} />
          </AreaChart>
        </ResponsiveContainer>
        <div className="flex items-center justify-between mt-1">
          <span className="text-xs text-gray-500">Tick Vol: <span className="text-gray-300 font-bold">{Math.round(volume)}</span></span>
          <span className="text-xs text-gray-500">Relativ: <span className={`font-bold ${relativeVolume > 1.5 ? "text-emerald-400" : "text-gray-300"}`}>{relativeVolume.toFixed(2)}x</span></span>
          {relativeVolume > 1.5 && (
            <span className="text-xs px-2 py-0.5 rounded-full font-bold" style={{ background: "rgba(16,185,129,0.2)", color: "#10b981", border: "1px solid rgba(16,185,129,0.3)" }}>
              🔥 VOLUME SPIKE
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
