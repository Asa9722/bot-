"use client";
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
  Cell, ReferenceLine,
} from "recharts";
import { formatUsd, WEEKDAYS } from "@/lib/utils";

interface Summary {
  total: number;
  wins: number;
  losses: number;
  winRate: number;
  totalProfit: number;
  avgProfit: number;
  avgLoss: number;
  profitFactor: number;
  avgRR: number;
  maxDrawdown: number;
  longTrades: number;
  shortTrades: number;
  longWinRate: number;
  shortWinRate: number;
  bestTrade: number;
  worstTrade: number;
}

interface EquityPoint {
  equity: number;
  balance: number;
  drawdown: number;
  openPositions: number;
  recordedAt: string | null;
}

interface RecentTrade {
  id: number;
  direction: string;
  profitUsd: number | null;
  profitPips: number | null;
  exitReason: string | null;
  openedAt: string | null;
  holdingMinutes: number | null;
  marketPhase: string | null;
  signalScore: number | null;
}

interface AdaptiveItem {
  paramName: string;
  paramValue: number;
  successRate: number | null;
  sampleCount: number | null;
  avgProfit: number | null;
}

interface Props {
  summary: Summary;
  equityData: EquityPoint[];
  byPhase: Record<string, { total: number; wins: number; profit: number }>;
  byExit: Record<string, { count: number; profit: number }>;
  byWeekday: Record<number, { profit: number; count: number }>;
  byHour: Record<number, { profit: number; count: number }>;
  bySession: Record<string, { profit: number; count: number }>;
  recentTrades: RecentTrade[];
  adaptive: AdaptiveItem[];
}

const TOOLTIP_STYLE = {
  background: "#0d1117",
  border: "1px solid #374151",
  borderRadius: 8,
  color: "#e5e7eb",
  fontSize: 11,
};

export default function PerformancePanel({
  summary, equityData, byPhase, byExit, byWeekday, byHour, bySession, recentTrades, adaptive
}: Props) {
  const equityChartData = equityData.map((e) => ({
    equity: e.equity,
    balance: e.balance,
    drawdown: e.drawdown,
    date: e.recordedAt ? new Date(e.recordedAt).toLocaleDateString("de-AT", { month: "2-digit", day: "2-digit" }) : "",
  }));

  const weekdayData = [0, 1, 2, 3, 4, 5, 6].map((d) => ({
    day: WEEKDAYS[d],
    profit: byWeekday[d]?.profit ?? 0,
    count: byWeekday[d]?.count ?? 0,
  }));

  const hourData = Array.from({ length: 24 }, (_, h) => ({
    hour: `${h}:00`,
    profit: byHour[h]?.profit ?? 0,
    count: byHour[h]?.count ?? 0,
  }));

  const phaseData = Object.entries(byPhase).map(([phase, d]) => ({
    phase,
    winRate: d.total > 0 ? Math.round((d.wins / d.total) * 100) : 0,
    profit: d.profit,
    total: d.total,
  }));

  const exitData = Object.entries(byExit).map(([exit, d]) => ({
    exit: exit.replace("_", " "),
    count: d.count,
    profit: d.profit,
  })).sort((a, b) => b.profit - a.profit);

  const sessionData = Object.entries(bySession).map(([session, d]) => ({
    session,
    profit: d.profit,
    count: d.count,
    avgProfit: d.count > 0 ? d.profit / d.count : 0,
  }));

  const statsCards = [
    { label: "Gesamt Trades", value: summary.total, color: "blue", fmt: (v: number) => v.toString() },
    { label: "Win Rate", value: summary.winRate, color: "green", fmt: (v: number) => `${v}%` },
    { label: "Profit Faktor", value: summary.profitFactor, color: "gold", fmt: (v: number) => v.toFixed(2) },
    { label: "Avg R:R", value: summary.avgRR, color: "purple", fmt: (v: number) => `1:${v.toFixed(2)}` },
    { label: "Gesamt Profit", value: summary.totalProfit, color: summary.totalProfit >= 0 ? "green" : "red", fmt: (v: number) => formatUsd(v) },
    { label: "Max Drawdown", value: summary.maxDrawdown, color: "red", fmt: (v: number) => `${v.toFixed(2)}%` },
    { label: "Bester Trade", value: summary.bestTrade, color: "green", fmt: (v: number) => formatUsd(v) },
    { label: "Schlechtester Trade", value: summary.worstTrade, color: "red", fmt: (v: number) => formatUsd(v) },
  ];

  const colorMap: Record<string, string> = {
    gold: "#f5c518", green: "#10b981", red: "#ef4444", blue: "#60a5fa", purple: "#a78bfa"
  };

  return (
    <div className="space-y-4">
      {/* Summary Cards */}
      <div className="grid grid-cols-4 gap-3">
        {statsCards.map((c) => (
          <div key={c.label} className="metric-card" style={{ borderTop: `2px solid ${colorMap[c.color] ?? "#374151"}40` }}>
            <div className="text-xs text-gray-500 mb-1">{c.label}</div>
            <div className="font-black text-xl" style={{ color: colorMap[c.color] ?? "#e5e7eb" }}>
              {c.fmt(c.value)}
            </div>
          </div>
        ))}
      </div>

      {/* Long vs Short */}
      <div className="grid grid-cols-2 gap-4">
        <div className="card">
          <div className="section-title">LONG vs SHORT ANALYSE</div>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-3 rounded-lg" style={{ background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.2)" }}>
              <div className="text-3xl font-black text-emerald-400">{summary.longWinRate}%</div>
              <div className="text-sm text-emerald-400 font-bold mt-1">▲ LONG</div>
              <div className="text-xs text-gray-400 mt-1">{summary.longTrades} Trades</div>
              <div className="mt-2 h-2 rounded-full bg-gray-800 overflow-hidden">
                <div className="h-full bg-emerald-400 rounded-full transition-all" style={{ width: `${summary.longWinRate}%` }}></div>
              </div>
            </div>
            <div className="text-center p-3 rounded-lg" style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)" }}>
              <div className="text-3xl font-black text-red-400">{summary.shortWinRate}%</div>
              <div className="text-sm text-red-400 font-bold mt-1">▼ SHORT</div>
              <div className="text-xs text-gray-400 mt-1">{summary.shortTrades} Trades</div>
              <div className="mt-2 h-2 rounded-full bg-gray-800 overflow-hidden">
                <div className="h-full bg-red-400 rounded-full transition-all" style={{ width: `${summary.shortWinRate}%` }}></div>
              </div>
            </div>
          </div>
        </div>

        {/* Sessions */}
        <div className="card">
          <div className="section-title">TRADING SESSIONS</div>
          <div className="space-y-2">
            {sessionData.map((s) => (
              <div key={s.session} className="flex items-center gap-3">
                <div className="text-xs font-bold w-24 text-gray-300">{s.session}</div>
                <div className="flex-1 h-6 rounded overflow-hidden" style={{ background: "#1f2937" }}>
                  <div
                    className="h-full flex items-center px-2 text-xs font-bold transition-all"
                    style={{
                      width: `${Math.min(100, Math.abs(s.profit) / 5)}%`,
                      background: s.profit >= 0 ? "linear-gradient(90deg,#10b981,#059669)" : "linear-gradient(90deg,#ef4444,#b91c1c)",
                      color: "white",
                      minWidth: 60,
                    }}
                  >
                    {formatUsd(s.profit)}
                  </div>
                </div>
                <div className="text-xs text-gray-500 w-16 text-right">{s.count} Trades</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Equity Curve */}
      <div className="card">
        <div className="font-bold text-white mb-3">📈 Equity Kurve (30 Tage)</div>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={equityChartData}>
            <defs>
              <linearGradient id="equityGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#f5c518" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#f5c518" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="balanceGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#60a5fa" stopOpacity={0.2} />
                <stop offset="95%" stopColor="#60a5fa" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" />
            <XAxis dataKey="date" tick={{ fill: "#6b7280", fontSize: 10 }} tickLine={false} interval={4} />
            <YAxis tick={{ fill: "#6b7280", fontSize: 10 }} tickLine={false} width={60} />
            <Tooltip contentStyle={TOOLTIP_STYLE} />
            <Area type="monotone" dataKey="balance" stroke="#60a5fa" strokeWidth={1.5} fill="url(#balanceGrad)" dot={false} name="Balance" />
            <Area type="monotone" dataKey="equity" stroke="#f5c518" strokeWidth={2} fill="url(#equityGrad)" dot={false} name="Equity" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Drawdown */}
      <div className="card">
        <div className="font-bold text-white mb-3">📉 Drawdown Chart</div>
        <ResponsiveContainer width="100%" height={100}>
          <AreaChart data={equityChartData}>
            <defs>
              <linearGradient id="ddGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#ef4444" stopOpacity={0.5} />
                <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="date" hide />
            <YAxis tick={{ fill: "#6b7280", fontSize: 10 }} tickLine={false} width={35} />
            <Tooltip contentStyle={TOOLTIP_STYLE} />
            <Area type="monotone" dataKey="drawdown" stroke="#ef4444" strokeWidth={2} fill="url(#ddGrad)" dot={false} name="Drawdown %" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* By Weekday */}
        <div className="card">
          <div className="section-title">PROFIT NACH WOCHENTAG</div>
          <ResponsiveContainer width="100%" height={150}>
            <BarChart data={weekdayData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" />
              <XAxis dataKey="day" tick={{ fill: "#6b7280", fontSize: 11 }} tickLine={false} />
              <YAxis tick={{ fill: "#6b7280", fontSize: 10 }} tickLine={false} width={40} />
              <Tooltip contentStyle={TOOLTIP_STYLE} />
              <Bar dataKey="profit" name="Profit $" radius={[3, 3, 0, 0]}>
                {weekdayData.map((entry, i) => (
                  <Cell key={i} fill={entry.profit >= 0 ? "#10b981" : "#ef4444"} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* By Market Phase */}
        <div className="card">
          <div className="section-title">MARKTPHASEN ANALYSE</div>
          <div className="space-y-3 mt-2">
            {phaseData.map((p) => (
              <div key={p.phase}>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-bold text-gray-300">{p.phase}</span>
                  <span className="text-xs text-gray-400">{p.total} Trades · {formatUsd(p.profit)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-4 rounded overflow-hidden" style={{ background: "#1f2937" }}>
                    <div className="h-full flex items-center justify-center text-xs font-bold text-black rounded transition-all" style={{
                      width: `${p.winRate}%`,
                      background: p.winRate >= 60 ? "linear-gradient(90deg,#10b981,#059669)" : "linear-gradient(90deg,#f59e0b,#d97706)",
                      minWidth: 30
                    }}>
                      {p.winRate}%
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Profit by Hour */}
      <div className="card">
        <div className="section-title">PROFIT NACH UHRZEIT (24H)</div>
        <ResponsiveContainer width="100%" height={120}>
          <BarChart data={hourData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" />
            <XAxis dataKey="hour" tick={{ fill: "#6b7280", fontSize: 9 }} tickLine={false} interval={2} />
            <YAxis tick={{ fill: "#6b7280", fontSize: 10 }} tickLine={false} width={40} />
            <ReferenceLine y={0} stroke="#374151" />
            <Tooltip contentStyle={TOOLTIP_STYLE} />
            <Bar dataKey="profit" name="Profit $" radius={[2, 2, 0, 0]}>
              {hourData.map((entry, i) => (
                <Cell key={i} fill={entry.profit >= 0 ? "#10b981" : "#ef4444"} fillOpacity={0.8} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Exit Reasons */}
      <div className="card">
        <div className="section-title">EXIT ANALYSE</div>
        <div className="space-y-2">
          {exitData.map((e) => (
            <div key={e.exit} className="flex items-center gap-3">
              <div className="text-xs text-gray-400 w-28 font-mono">{e.exit}</div>
              <div className="flex-1 h-6 rounded overflow-hidden" style={{ background: "#1f2937" }}>
                <div className="h-full flex items-center px-2 text-xs font-bold" style={{
                  width: `${Math.min(100, (e.count / Math.max(...exitData.map(x => x.count))) * 100)}%`,
                  background: e.profit >= 0 ? "linear-gradient(90deg,#10b981,#059669)" : "linear-gradient(90deg,#ef4444,#b91c1c)",
                  color: "white", minWidth: 40
                }}>
                  {e.count}x
                </div>
              </div>
              <div className={`text-xs font-bold w-20 text-right ${e.profit >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                {formatUsd(e.profit)}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Trades Table */}
      <div className="card" style={{ padding: 0 }}>
        <div className="px-4 py-3 font-bold text-white" style={{ borderBottom: "1px solid #1f2937" }}>
          📋 Letzte 20 Trades
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-gray-500 font-bold uppercase" style={{ borderBottom: "1px solid #1f2937" }}>
                <th className="text-left px-4 py-2">Dir</th>
                <th className="text-left px-4 py-2">Phase</th>
                <th className="text-left px-4 py-2">Score</th>
                <th className="text-left px-4 py-2">Dauer</th>
                <th className="text-left px-4 py-2">Exit</th>
                <th className="text-right px-4 py-2">Pips</th>
                <th className="text-right px-4 py-2">P&L</th>
              </tr>
            </thead>
            <tbody>
              {recentTrades.map((t) => (
                <tr key={t.id} className="trade-row">
                  <td className="px-4 py-2">
                    <span className={`font-bold ${t.direction === "LONG" ? "text-emerald-400" : "text-red-400"}`}>
                      {t.direction === "LONG" ? "▲" : "▼"} {t.direction}
                    </span>
                  </td>
                  <td className="px-4 py-2 text-gray-400">{t.marketPhase ?? "–"}</td>
                  <td className="px-4 py-2">
                    <span className={`font-bold ${(t.signalScore ?? 0) >= 75 ? "text-emerald-400" : (t.signalScore ?? 0) >= 55 ? "text-yellow-400" : "text-red-400"}`}>
                      {t.signalScore ?? "–"}
                    </span>
                  </td>
                  <td className="px-4 py-2 text-gray-400">
                    {t.holdingMinutes ? `${t.holdingMinutes}m` : "–"}
                  </td>
                  <td className="px-4 py-2 text-gray-400 font-mono text-xs">{t.exitReason?.replace("_", " ") ?? "–"}</td>
                  <td className={`px-4 py-2 text-right font-bold ${(t.profitPips ?? 0) >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                    {t.profitPips != null ? `${t.profitPips > 0 ? "+" : ""}${t.profitPips.toFixed(1)}` : "–"}
                  </td>
                  <td className={`px-4 py-2 text-right font-bold ${(t.profitUsd ?? 0) >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                    {t.profitUsd != null ? `${t.profitUsd > 0 ? "+" : ""}$${Math.abs(t.profitUsd).toFixed(2)}` : "–"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Adaptive Learning */}
      <div className="card">
        <div className="section-title">🧠 ADAPTIVE PARAMETER (LERNMODUS)</div>
        <div className="grid grid-cols-4 gap-3">
          {adaptive.map((a) => (
            <div key={a.paramName} className="p-3 rounded-lg" style={{ background: "#0a0d13", border: "1px solid #1f2937" }}>
              <div className="text-xs text-gray-500 mb-1 font-mono">{a.paramName}</div>
              <div className="font-black text-lg" style={{ color: "#f5c518" }}>{a.paramValue.toFixed(2)}</div>
              <div className="flex items-center gap-1 mt-1">
                <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: "#1f2937" }}>
                  <div className="h-full rounded-full" style={{
                    width: `${a.successRate ?? 0}%`,
                    background: (a.successRate ?? 0) >= 60 ? "#10b981" : "#f59e0b"
                  }}></div>
                </div>
                <span className="text-xs font-bold text-gray-300">{a.successRate?.toFixed(1)}%</span>
              </div>
              <div className="text-xs text-gray-600 mt-1">{a.sampleCount} Samples · Ø ${a.avgProfit?.toFixed(0)}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
