"use client";
import { useState } from "react";
import { formatPrice, formatUsd, formatDateTime, profitColor } from "@/lib/utils";

interface Trade {
  id: number;
  ticketId: string | null;
  direction: string;
  status: string;
  entryPrice: number;
  currentPrice: number | null;
  stopLoss: number | null;
  takeProfit: number | null;
  lotSize: number;
  signalScore: number | null;
  signalReason: string | null;
  marketPhase: string | null;
  trendStrength: number | null;
  atrAtEntry: number | null;
  rsiAtEntry: number | null;
  adxAtEntry: number | null;
  trailingActive: boolean | null;
  breakEvenSet: boolean | null;
  partialClosed: boolean | null;
  openedAt: string | null;
}

interface Props {
  trades: Trade[];
  goldPrice: number;
  onClose: (id: number) => void;
  onPartial: (id: number, pct: number) => void;
  onModify: (id: number, sl: number, tp: number) => void;
}

export default function OpenTrades({ trades, goldPrice, onClose, onPartial, onModify }: Props) {
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [editSL, setEditSL] = useState<Record<number, string>>({});
  const [editTP, setEditTP] = useState<Record<number, string>>({});

  const calcProfit = (t: Trade): number => {
    const price = t.currentPrice ?? goldPrice;
    const diff = t.direction === "LONG" ? price - t.entryPrice : t.entryPrice - price;
    return diff * t.lotSize * 100;
  };

  const calcProfitPct = (t: Trade): number => {
    const price = t.currentPrice ?? goldPrice;
    const diff = t.direction === "LONG" ? price - t.entryPrice : t.entryPrice - price;
    return (diff / t.entryPrice) * 100;
  };

  const distToSL = (t: Trade): number => {
    if (!t.stopLoss) return 0;
    const price = t.currentPrice ?? goldPrice;
    return Math.abs(price - t.stopLoss);
  };

  const distToTP = (t: Trade): number => {
    if (!t.takeProfit) return 0;
    const price = t.currentPrice ?? goldPrice;
    return Math.abs(price - t.takeProfit);
  };

  if (trades.length === 0) {
    return (
      <div className="card text-center py-12">
        <div className="text-4xl mb-3">🔍</div>
        <div className="text-gray-400 font-semibold">Keine offenen Positionen</div>
        <div className="text-gray-600 text-sm mt-1">Der Bot sucht aktiv nach Einstiegen...</div>
      </div>
    );
  }

  return (
    <div className="card" style={{ padding: 0 }}>
      <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: "1px solid #1f2937" }}>
        <div className="flex items-center gap-2">
          <span className="font-bold text-white">Offene Positionen</span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-yellow-500/20 text-yellow-400 border border-yellow-500/30">
            {trades.length} aktiv
          </span>
        </div>
        <div className="text-sm text-gray-400">
          Gesamt P&L:{" "}
          <span className={`font-bold ${profitColor(trades.reduce((s, t) => s + calcProfit(t), 0))}`}>
            {formatUsd(trades.reduce((s, t) => s + calcProfit(t), 0))}
          </span>
        </div>
      </div>

      {/* Table Header */}
      <div className="grid text-xs font-bold text-gray-500 uppercase px-4 py-2 gap-2" style={{
        gridTemplateColumns: "1fr 60px 70px 80px 80px 80px 80px 100px 120px"
      }}>
        <span>Ticket</span>
        <span>Dir</span>
        <span>Lots</span>
        <span>Entry</span>
        <span>Preis</span>
        <span>SL</span>
        <span>TP</span>
        <span>P&L</span>
        <span>Aktionen</span>
      </div>

      {trades.map((t) => {
        const profit = calcProfit(t);
        const profPct = calcProfitPct(t);
        const isExpanded = expandedId === t.id;
        const slDist = distToSL(t);
        const tpDist = distToTP(t);

        return (
          <div key={t.id}>
            <div
              className="trade-row grid items-center px-4 py-3 gap-2 cursor-pointer"
              style={{ gridTemplateColumns: "1fr 60px 70px 80px 80px 80px 80px 100px 120px" }}
              onClick={() => setExpandedId(isExpanded ? null : t.id)}
            >
              {/* Ticket */}
              <div>
                <div className="font-mono text-xs text-gray-300">{t.ticketId?.slice(-8) ?? "–"}</div>
                <div className="flex items-center gap-1 mt-0.5">
                  {t.trailingActive && (
                    <span className="text-xs px-1 rounded" style={{ background: "rgba(59,130,246,0.2)", color: "#60a5fa", fontSize: 9 }}>TRAIL</span>
                  )}
                  {t.breakEvenSet && (
                    <span className="text-xs px-1 rounded" style={{ background: "rgba(245,197,24,0.2)", color: "#f5c518", fontSize: 9 }}>BE</span>
                  )}
                  {t.partialClosed && (
                    <span className="text-xs px-1 rounded" style={{ background: "rgba(139,92,246,0.2)", color: "#a78bfa", fontSize: 9 }}>50%</span>
                  )}
                </div>
              </div>

              {/* Direction */}
              <div className={`font-bold text-sm ${t.direction === "LONG" ? "text-emerald-400" : "text-red-400"}`}>
                {t.direction === "LONG" ? "▲ L" : "▼ S"}
              </div>

              {/* Lots */}
              <div className="text-xs text-gray-300">{t.lotSize.toFixed(2)}</div>

              {/* Entry */}
              <div className="text-xs font-mono text-gray-300">{formatPrice(t.entryPrice, 2)}</div>

              {/* Current */}
              <div className="text-xs font-mono font-bold text-white">
                {formatPrice(t.currentPrice ?? goldPrice, 2)}
              </div>

              {/* SL */}
              <div className="text-xs font-mono text-red-400">{formatPrice(t.stopLoss, 2)}</div>

              {/* TP */}
              <div className="text-xs font-mono text-emerald-400">{formatPrice(t.takeProfit, 2)}</div>

              {/* P&L */}
              <div>
                <div className={`font-bold text-sm ${profitColor(profit)}`}>{formatUsd(profit)}</div>
                <div className={`text-xs ${profitColor(profPct)}`}>{profPct >= 0 ? "+" : ""}{profPct.toFixed(2)}%</div>
              </div>

              {/* Actions */}
              <div className="flex gap-1" onClick={(e) => e.stopPropagation()}>
                <button
                  className="text-xs px-2 py-1 rounded font-bold transition-all"
                  style={{ background: "rgba(245,197,24,0.15)", color: "#f5c518", border: "1px solid rgba(245,197,24,0.3)" }}
                  onClick={() => onPartial(t.id, 50)}
                  title="50% Teilverkauf"
                >
                  50%
                </button>
                <button
                  className="btn-red text-xs py-1 px-2"
                  onClick={() => onClose(t.id)}
                  title="Schließen"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Expanded Detail */}
            {isExpanded && (
              <div className="px-4 pb-4" style={{ background: "rgba(245,197,24,0.02)", borderBottom: "1px solid #1f2937" }}>
                <div className="grid grid-cols-2 gap-4 mt-3">
                  {/* Signal Info */}
                  <div className="space-y-2">
                    <div className="section-title">🎯 Einstiegssignal</div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-500">Score:</span>
                      <div className="flex items-center gap-1 flex-1">
                        <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: "#1f2937" }}>
                          <div className="h-full rounded-full" style={{
                            width: `${t.signalScore ?? 0}%`,
                            background: (t.signalScore ?? 0) >= 75 ? "#10b981" : "#f59e0b"
                          }}></div>
                        </div>
                        <span className="text-xs font-bold text-white">{t.signalScore}/100</span>
                      </div>
                    </div>
                    <div className="text-xs text-gray-300">{t.signalReason ?? "–"}</div>
                    <div className="grid grid-cols-3 gap-2 mt-2">
                      <div className="text-center p-1.5 rounded" style={{ background: "#1f2937" }}>
                        <div className="text-xs text-gray-500">RSI</div>
                        <div className="font-bold text-white text-sm">{t.rsiAtEntry?.toFixed(1) ?? "–"}</div>
                      </div>
                      <div className="text-center p-1.5 rounded" style={{ background: "#1f2937" }}>
                        <div className="text-xs text-gray-500">ADX</div>
                        <div className="font-bold text-white text-sm">{t.adxAtEntry?.toFixed(1) ?? "–"}</div>
                      </div>
                      <div className="text-center p-1.5 rounded" style={{ background: "#1f2937" }}>
                        <div className="text-xs text-gray-500">ATR</div>
                        <div className="font-bold text-white text-sm">{t.atrAtEntry?.toFixed(1) ?? "–"}</div>
                      </div>
                    </div>
                    <div className="text-xs text-gray-500 mt-2">
                      Phase: <span className="text-gray-300">{t.marketPhase ?? "–"}</span>
                      {" · "}Geöffnet: <span className="text-gray-300">{formatDateTime(t.openedAt)}</span>
                    </div>
                  </div>

                  {/* Modify */}
                  <div className="space-y-2">
                    <div className="section-title">⚙️ Position ändern</div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-xs text-gray-500 block mb-1">Stop Loss</label>
                        <input
                          type="number"
                          step="0.01"
                          className="input-dark"
                          placeholder={formatPrice(t.stopLoss, 2)}
                          value={editSL[t.id] ?? ""}
                          onChange={(e) => setEditSL((p) => ({ ...p, [t.id]: e.target.value }))}
                        />
                      </div>
                      <div>
                        <label className="text-xs text-gray-500 block mb-1">Take Profit</label>
                        <input
                          type="number"
                          step="0.01"
                          className="input-dark"
                          placeholder={formatPrice(t.takeProfit, 2)}
                          value={editTP[t.id] ?? ""}
                          onChange={(e) => setEditTP((p) => ({ ...p, [t.id]: e.target.value }))}
                        />
                      </div>
                    </div>
                    <button
                      className="btn-gold text-xs w-full py-2"
                      onClick={() => {
                        const sl = parseFloat(editSL[t.id] ?? String(t.stopLoss ?? 0));
                        const tp = parseFloat(editTP[t.id] ?? String(t.takeProfit ?? 0));
                        onModify(t.id, sl, tp);
                      }}
                    >
                      ✏️ Änderungen speichern
                    </button>
                    <div className="grid grid-cols-2 gap-2 mt-1 text-xs text-center">
                      <div className="p-1.5 rounded" style={{ background: "#1f2937" }}>
                        <div className="text-gray-500">Abstand SL</div>
                        <div className="font-bold text-red-400">{slDist.toFixed(1)} Pkt</div>
                      </div>
                      <div className="p-1.5 rounded" style={{ background: "#1f2937" }}>
                        <div className="text-gray-500">Abstand TP</div>
                        <div className="font-bold text-emerald-400">{tpDist.toFixed(1)} Pkt</div>
                      </div>
                    </div>
                    <div className="flex gap-1 mt-1">
                      <button className="btn-outline text-xs flex-1 py-1.5" onClick={() => onPartial(t.id, 25)}>25% schließen</button>
                      <button className="btn-outline text-xs flex-1 py-1.5" onClick={() => onPartial(t.id, 75)}>75% schließen</button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
