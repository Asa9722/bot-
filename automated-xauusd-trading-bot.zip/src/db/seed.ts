import { db } from "./index";
import {
  botSettings,
  trades,
  marketSnapshots,
  performanceLogs,
  equityCurve,
  systemLogs,
  adaptiveData,
} from "./schema";

const defaultSettings: { key: string; value: string }[] = [
  // Strategy
  { key: "bot_active", value: "true" },
  { key: "bot_mode", value: "LIVE" }, // LIVE | PAPER | PAUSE
  { key: "signal_score_min", value: "65" },
  { key: "rsi_period", value: "14" },
  { key: "rsi_oversold", value: "30" },
  { key: "rsi_overbought", value: "70" },
  { key: "ema_fast", value: "20" },
  { key: "ema_mid", value: "50" },
  { key: "ema_slow", value: "100" },
  { key: "ema_trend", value: "200" },
  { key: "adx_minimum", value: "20" },
  { key: "atr_period", value: "14" },
  { key: "macd_fast", value: "12" },
  { key: "macd_slow", value: "26" },
  { key: "macd_signal", value: "9" },
  { key: "trend_filter", value: "true" },
  { key: "volume_filter", value: "true" },
  { key: "tf_15m_weight", value: "25" },
  { key: "tf_1h_weight", value: "45" },
  { key: "tf_4h_weight", value: "30" },
  // Risk – Trade Level
  { key: "sl_type", value: "ATR" }, // FIXED | PERCENT | ATR | DYNAMIC
  { key: "sl_fixed_pips", value: "200" },
  { key: "sl_percent", value: "1.5" },
  { key: "sl_atr_multiplier", value: "2.0" },
  { key: "tp_type", value: "DYNAMIC" },
  { key: "tp_atr_multiplier", value: "3.0" },
  { key: "trailing_stop", value: "true" },
  { key: "trailing_type", value: "ATR" }, // STATIC | ATR
  { key: "trailing_start_percent", value: "1.0" },
  { key: "trailing_distance_atr", value: "1.5" },
  { key: "break_even", value: "true" },
  { key: "break_even_trigger_percent", value: "0.5" },
  { key: "partial_close", value: "true" },
  { key: "partial_close_percent", value: "50" },
  { key: "partial_trigger_percent", value: "1.0" },
  { key: "momentum_exit", value: "true" },
  { key: "dynamic_tp", value: "true" },
  // Risk – Account Level
  { key: "risk_per_trade_percent", value: "1.0" },
  { key: "risk_per_series_percent", value: "3.0" },
  { key: "max_open_trades", value: "10" },
  { key: "max_trades_per_hour", value: "5" },
  { key: "max_trades_per_day", value: "20" },
  { key: "max_daily_loss_percent", value: "5.0" },
  { key: "max_weekly_loss_percent", value: "10.0" },
  { key: "max_drawdown_percent", value: "15.0" },
  { key: "equity_protection_percent", value: "80.0" },
  { key: "max_long_positions", value: "7" },
  { key: "max_short_positions", value: "7" },
  // Protections
  { key: "pause_after_losses", value: "3" },
  { key: "pause_high_volatility", value: "true" },
  { key: "news_stop", value: "true" },
  { key: "max_spread_pips", value: "30" },
  { key: "max_slippage_pips", value: "10" },
  // Multi-Trade
  { key: "multi_entry", value: "true" },
  { key: "min_entry_distance_pips", value: "50" },
  { key: "scaling_factor", value: "0.75" },
  { key: "position_multiplier", value: "1.0" },
  { key: "hedging_allowed", value: "false" },
  // Adaptive Learning
  { key: "adaptive_mode", value: "true" },
  { key: "learn_interval_trades", value: "50" },
  { key: "auto_param_adjust", value: "true" },
  // Telegram
  { key: "telegram_enabled", value: "false" },
  { key: "telegram_bot_token", value: "" },
  { key: "telegram_chat_id", value: "" },
  // Account
  { key: "mt5_account", value: "123456789" },
  { key: "mt5_server", value: "ICMarkets-Demo" },
  { key: "account_balance", value: "10000" },
  { key: "account_equity", value: "10247.50" },
  { key: "account_currency", value: "USD" },
  { key: "timezone", value: "Europe/Vienna" },
];

function randomBetween(min: number, max: number) {
  return Math.random() * (max - min) + min;
}

function randomInt(min: number, max: number) {
  return Math.floor(randomBetween(min, max + 1));
}

async function seed() {
  console.log("🌱 Seeding database...");

  // Settings
  for (const s of defaultSettings) {
    await db
      .insert(botSettings)
      .values(s)
      .onConflictDoNothing();
  }
  console.log("✅ Settings seeded");

  // Adaptive data
  const params = [
    { name: "rsi_period", value: 14 },
    { name: "atr_multiplier_sl", value: 2.0 },
    { name: "atr_multiplier_tp", value: 3.0 },
    { name: "signal_score_min", value: 65 },
    { name: "adx_minimum", value: 20 },
    { name: "trailing_distance", value: 1.5 },
    { name: "ema_fast", value: 20 },
    { name: "ema_slow", value: 200 },
  ];
  for (const p of params) {
    await db.insert(adaptiveData).values({
      paramName: p.name,
      paramValue: p.value,
      successRate: randomBetween(55, 75),
      sampleCount: randomInt(30, 200),
      avgProfit: randomBetween(20, 80),
    }).onConflictDoNothing();
  }
  console.log("✅ Adaptive data seeded");

  // Market Snapshots (last 120 minutes)
  const basePrice = 2345.50;
  const snapshots = [];
  for (let i = 120; i >= 0; i--) {
    const price = basePrice + randomBetween(-15, 15);
    snapshots.push({
      price,
      bid: price - 0.15,
      ask: price + 0.15,
      spread: 0.30,
      atr: randomBetween(8, 18),
      rsi: randomBetween(35, 70),
      macd: randomBetween(-2, 2),
      macdSignal: randomBetween(-1.5, 1.5),
      ema20: price - randomBetween(-5, 5),
      ema50: price - randomBetween(-10, 10),
      ema100: price - randomBetween(-15, 15),
      ema200: price - randomBetween(-25, 25),
      adx: randomBetween(15, 45),
      stochK: randomBetween(20, 80),
      stochD: randomBetween(20, 80),
      bbUpper: price + randomBetween(8, 18),
      bbLower: price - randomBetween(8, 18),
      bbMiddle: price + randomBetween(-3, 3),
      volume: randomBetween(500, 3000),
      relativeVolume: randomBetween(0.5, 2.5),
      signalScore: randomInt(40, 92),
      marketPhase: ["TREND", "RANGE", "BREAKOUT"][randomInt(0, 2)],
      trendDirection: ["LONG", "SHORT", "NEUTRAL"][randomInt(0, 2)],
      recordedAt: new Date(Date.now() - i * 60 * 1000),
    });
  }
  await db.insert(marketSnapshots).values(snapshots).onConflictDoNothing();
  console.log("✅ Market snapshots seeded");

  // Equity Curve (last 30 days)
  let equity = 10000;
  let balance = 10000;
  let peak = equity;
  const equityRows = [];
  for (let i = 30; i >= 0; i--) {
    const change = randomBetween(-120, 180);
    equity = Math.max(8500, equity + change);
    balance = equity - randomBetween(0, 200);
    peak = Math.max(peak, equity);
    equityRows.push({
      equity: Math.round(equity * 100) / 100,
      balance: Math.round(balance * 100) / 100,
      drawdown: Math.round(((peak - equity) / peak) * 10000) / 100,
      openPositions: randomInt(0, 8),
      recordedAt: new Date(Date.now() - i * 24 * 60 * 60 * 1000),
    });
  }
  await db.insert(equityCurve).values(equityRows).onConflictDoNothing();
  console.log("✅ Equity curve seeded");

  // Trades (last 30 days – mix of open and closed)
  const directions: ("LONG" | "SHORT")[] = ["LONG", "SHORT"];
  const phases: string[] = ["TREND", "RANGE", "BREAKOUT"];
  const exitReasons = [
    "TAKE_PROFIT", "TRAILING_STOP", "PARTIAL_TP", "MOMENTUM_EXIT",
    "BREAK_EVEN", "STOP_LOSS", "MANUAL"
  ];
  const signalReasons = [
    "EMA Cross + RSI 42 + ADX 28 + Volume Spike",
    "Breakout + MACD Cross + Stoch 23 + Trend Strong",
    "Pullback Entry + EMA 50 bounce + RSI 38",
    "Range Support + BB Lower + Stoch Oversold",
    "4H Trend + 1H Signal + 15M Entry Confirmed",
  ];

  const tradeRows = [];
  for (let i = 0; i < 80; i++) {
    const dir = directions[randomInt(0, 1)];
    const ep = basePrice + randomBetween(-50, 50);
    const atr = randomBetween(8, 18);
    const sl = dir === "LONG" ? ep - atr * 2 : ep + atr * 2;
    const tp = dir === "LONG" ? ep + atr * 3 : ep - atr * 3;
    const won = Math.random() > 0.38;
    const exitP = won
      ? dir === "LONG" ? ep + randomBetween(5, atr * 3.5) : ep - randomBetween(5, atr * 3.5)
      : dir === "LONG" ? ep - randomBetween(5, atr * 2.5) : ep + randomBetween(5, atr * 2.5);
    const profit = dir === "LONG" ? (exitP - ep) * 10 : (ep - exitP) * 10;
    const holdMins = randomInt(15, 480);
    const daysAgo = randomInt(0, 30);
    const openedAt = new Date(Date.now() - daysAgo * 86400000 - holdMins * 60000);
    const closedAt = new Date(openedAt.getTime() + holdMins * 60000);
    const isOpen = i >= 74; // last 6 are open

    tradeRows.push({
      ticketId: `XAU${Date.now()}${i}`,
      symbol: "XAUUSD",
      direction: dir,
      status: isOpen ? "OPEN" : (Math.random() > 0.8 ? "PARTIAL" : "CLOSED"),
      entryPrice: Math.round(ep * 100) / 100,
      currentPrice: isOpen ? Math.round((ep + randomBetween(-8, 12)) * 100) / 100 : null,
      exitPrice: isOpen ? null : Math.round(exitP * 100) / 100,
      stopLoss: Math.round(sl * 100) / 100,
      takeProfit: Math.round(tp * 100) / 100,
      lotSize: randomBetween(0.05, 0.5),
      signalScore: randomInt(65, 95),
      signalReason: signalReasons[randomInt(0, signalReasons.length - 1)],
      exitReason: isOpen ? null : exitReasons[randomInt(0, exitReasons.length - 1)],
      marketPhase: phases[randomInt(0, 2)],
      trendStrength: randomBetween(20, 80),
      atrAtEntry: Math.round(atr * 100) / 100,
      volatilityAtEntry: randomBetween(0.5, 2.0),
      rsiAtEntry: randomBetween(28, 72),
      adxAtEntry: randomBetween(15, 50),
      macdAtEntry: randomBetween(-3, 3),
      spreadAtEntry: randomBetween(0.2, 0.5),
      profitPips: isOpen ? null : Math.round((exitP - ep) * (dir === "LONG" ? 1 : -1) * 10) / 10,
      profitUsd: isOpen ? null : Math.round(profit * 100) / 100,
      profitPercent: isOpen ? null : Math.round((profit / 10000) * 10000) / 100,
      holdingMinutes: isOpen ? null : holdMins,
      breakEvenSet: Math.random() > 0.5,
      trailingActive: Math.random() > 0.6,
      partialClosed: Math.random() > 0.7,
      partialPercent: Math.random() > 0.7 ? 50 : null,
      parametersUsed: { rsi: 14, atr: 14, ema_fast: 20, sl_type: "ATR" },
      openedAt,
      closedAt: isOpen ? null : closedAt,
    });
  }
  await db.insert(trades).values(tradeRows).onConflictDoNothing();
  console.log("✅ Trades seeded");

  // Performance Logs
  const sessions = ["LONDON", "NEW_YORK", "ASIAN"];
  const perfRows = [];
  for (let d = 30; d >= 0; d--) {
    const date = new Date(Date.now() - d * 86400000);
    const dd = String(date.getDate()).padStart(2, "0");
    const mm = String(date.getMonth() + 1).padStart(2, "0");
    const yyyy = date.getFullYear();
    for (let h = 0; h < 24; h += 3) {
      const total = randomInt(0, 5);
      const wins = randomInt(0, total);
      const longs = randomInt(0, total);
      const profit = randomBetween(-150, 250);
      perfRows.push({
        date: `${dd}.${mm}.${yyyy}`,
        hour: h,
        weekday: date.getDay(),
        session: sessions[randomInt(0, 2)],
        totalTrades: total,
        winTrades: wins,
        lossTrades: total - wins,
        longTrades: longs,
        shortTrades: total - longs,
        profitUsd: Math.round(profit * 100) / 100,
        profitPercent: Math.round((profit / 10000) * 10000) / 100,
        maxDrawdown: randomBetween(0, 3),
        avgRR: randomBetween(1.0, 3.5),
        winRate: total > 0 ? Math.round((wins / total) * 1000) / 10 : 0,
      });
    }
  }
  await db.insert(performanceLogs).values(perfRows).onConflictDoNothing();
  console.log("✅ Performance logs seeded");

  // System logs
  const logEntries = [
    { level: "INFO", category: "BOT", message: "Bot gestartet – XAUUSD Trading aktiv" },
    { level: "INFO", category: "TRADE", message: "Trade #XAU001 eröffnet: LONG 0.10 @ 2345.20" },
    { level: "INFO", category: "TRADE", message: "Break-Even gesetzt für Trade #XAU002" },
    { level: "INFO", category: "TRADE", message: "Trailing Stop aktiviert @ 2362.80" },
    { level: "WARN", category: "RISK", message: "Spread zu hoch: 45 Pips – Trade übersprungen" },
    { level: "INFO", category: "TRADE", message: "Teilverkauf 50% durchgeführt – Trade #XAU003" },
    { level: "INFO", category: "ADAPT", message: "Adaptive Optimierung: ATR Multiplier angepasst 2.0 → 2.2" },
    { level: "INFO", category: "TRADE", message: "Trade #XAU004 geschlossen: +$127.40 (Trailing Stop)" },
    { level: "WARN", category: "RISK", message: "3 Verluste in Folge – Pause aktiviert (30 min)" },
    { level: "INFO", category: "BOT", message: "Pause beendet – Bot wieder aktiv" },
    { level: "ERROR", category: "API", message: "MT5 Verbindung unterbrochen – Reconnect..." },
    { level: "INFO", category: "API", message: "MT5 Verbindung wiederhergestellt" },
    { level: "INFO", category: "SIGNAL", message: "Signal Score: 78/100 – LONG Signal generiert" },
    { level: "INFO", category: "LEARN", message: "Lernzyklus #5 abgeschlossen – 50 Trades analysiert" },
  ];
  for (const l of logEntries) {
    await db.insert(systemLogs).values({
      ...l,
      level: l.level as "INFO" | "WARN" | "ERROR",
      createdAt: new Date(Date.now() - randomInt(0, 3600) * 1000),
    }).onConflictDoNothing();
  }
  console.log("✅ System logs seeded");

  console.log("🎉 Database seeded successfully!");
}

seed().catch(console.error);
