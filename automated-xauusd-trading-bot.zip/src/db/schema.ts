import {
  pgTable,
  serial,
  text,
  real,
  integer,
  boolean,
  timestamp,
  jsonb,
  varchar,
} from "drizzle-orm/pg-core";

// ─────────────────────────────────────────────
// BOT SETTINGS
// ─────────────────────────────────────────────
export const botSettings = pgTable("bot_settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 128 }).notNull().unique(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ─────────────────────────────────────────────
// TRADES
// ─────────────────────────────────────────────
export const trades = pgTable("trades", {
  id: serial("id").primaryKey(),
  ticketId: varchar("ticket_id", { length: 64 }).unique(),
  symbol: varchar("symbol", { length: 16 }).notNull().default("XAUUSD"),
  direction: varchar("direction", { length: 8 }).notNull(), // LONG | SHORT
  status: varchar("status", { length: 16 }).notNull().default("OPEN"), // OPEN | CLOSED | PARTIAL
  entryPrice: real("entry_price").notNull(),
  currentPrice: real("current_price"),
  exitPrice: real("exit_price"),
  stopLoss: real("stop_loss"),
  takeProfit: real("take_profit"),
  lotSize: real("lot_size").notNull(),
  signalScore: integer("signal_score"),
  signalReason: text("signal_reason"),
  exitReason: text("exit_reason"),
  marketPhase: varchar("market_phase", { length: 32 }), // TREND | RANGE | BREAKOUT
  trendStrength: real("trend_strength"),
  atrAtEntry: real("atr_at_entry"),
  volatilityAtEntry: real("volatility_at_entry"),
  rsiAtEntry: real("rsi_at_entry"),
  adxAtEntry: real("adx_at_entry"),
  macdAtEntry: real("macd_at_entry"),
  spreadAtEntry: real("spread_at_entry"),
  profitPips: real("profit_pips"),
  profitUsd: real("profit_usd"),
  profitPercent: real("profit_percent"),
  holdingMinutes: integer("holding_minutes"),
  breakEvenSet: boolean("break_even_set").default(false),
  trailingActive: boolean("trailing_active").default(false),
  partialClosed: boolean("partial_closed").default(false),
  partialPercent: real("partial_percent"),
  parametersUsed: jsonb("parameters_used"),
  openedAt: timestamp("opened_at").defaultNow(),
  closedAt: timestamp("closed_at"),
});

// ─────────────────────────────────────────────
// MARKET SNAPSHOTS
// ─────────────────────────────────────────────
export const marketSnapshots = pgTable("market_snapshots", {
  id: serial("id").primaryKey(),
  price: real("price").notNull(),
  bid: real("bid"),
  ask: real("ask"),
  spread: real("spread"),
  atr: real("atr"),
  rsi: real("rsi"),
  macd: real("macd"),
  macdSignal: real("macd_signal"),
  ema20: real("ema20"),
  ema50: real("ema50"),
  ema100: real("ema100"),
  ema200: real("ema200"),
  adx: real("adx"),
  stochK: real("stoch_k"),
  stochD: real("stoch_d"),
  bbUpper: real("bb_upper"),
  bbLower: real("bb_lower"),
  bbMiddle: real("bb_middle"),
  volume: real("volume"),
  relativeVolume: real("relative_volume"),
  signalScore: integer("signal_score"),
  marketPhase: varchar("market_phase", { length: 32 }),
  trendDirection: varchar("trend_direction", { length: 8 }),
  recordedAt: timestamp("recorded_at").defaultNow(),
});

// ─────────────────────────────────────────────
// PERFORMANCE LOGS (hourly aggregates)
// ─────────────────────────────────────────────
export const performanceLogs = pgTable("performance_logs", {
  id: serial("id").primaryKey(),
  date: varchar("date", { length: 16 }).notNull(), // DD.MM.YYYY
  hour: integer("hour"),
  weekday: integer("weekday"), // 0=Mon..6=Sun
  session: varchar("session", { length: 16 }), // LONDON | NEW_YORK | ASIAN
  totalTrades: integer("total_trades").default(0),
  winTrades: integer("win_trades").default(0),
  lossTrades: integer("loss_trades").default(0),
  longTrades: integer("long_trades").default(0),
  shortTrades: integer("short_trades").default(0),
  profitUsd: real("profit_usd").default(0),
  profitPercent: real("profit_percent").default(0),
  maxDrawdown: real("max_drawdown").default(0),
  avgRR: real("avg_rr").default(0),
  winRate: real("win_rate").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// ─────────────────────────────────────────────
// EQUITY CURVE
// ─────────────────────────────────────────────
export const equityCurve = pgTable("equity_curve", {
  id: serial("id").primaryKey(),
  equity: real("equity").notNull(),
  balance: real("balance").notNull(),
  drawdown: real("drawdown").default(0),
  openPositions: integer("open_positions").default(0),
  recordedAt: timestamp("recorded_at").defaultNow(),
});

// ─────────────────────────────────────────────
// TELEGRAM LOGS
// ─────────────────────────────────────────────
export const telegramLogs = pgTable("telegram_logs", {
  id: serial("id").primaryKey(),
  messageType: varchar("message_type", { length: 64 }),
  message: text("message"),
  sent: boolean("sent").default(false),
  sentAt: timestamp("sent_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ─────────────────────────────────────────────
// SYSTEM LOGS
// ─────────────────────────────────────────────
export const systemLogs = pgTable("system_logs", {
  id: serial("id").primaryKey(),
  level: varchar("level", { length: 16 }).notNull(), // INFO | WARN | ERROR
  category: varchar("category", { length: 32 }),
  message: text("message").notNull(),
  data: jsonb("data"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ─────────────────────────────────────────────
// LEARNING / ADAPTIVE DATA
// ─────────────────────────────────────────────
export const adaptiveData = pgTable("adaptive_data", {
  id: serial("id").primaryKey(),
  paramName: varchar("param_name", { length: 64 }).notNull(),
  paramValue: real("param_value").notNull(),
  successRate: real("success_rate").default(0),
  sampleCount: integer("sample_count").default(0),
  avgProfit: real("avg_profit").default(0),
  updatedAt: timestamp("updated_at").defaultNow(),
});
